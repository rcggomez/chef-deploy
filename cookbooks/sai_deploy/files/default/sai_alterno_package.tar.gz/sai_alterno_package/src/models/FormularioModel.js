const dbConection = require("../config/postgressdb");
const { Sequelize, DataTypes, QueryTypes } = require("sequelize");

const FormularioModel = dbConection.define(
  'formulario_clue',
  {
    id_formulario: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    fecha_registro: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    hora_registro: {
      type: DataTypes.TIME,
      allowNull: false,
    },
    entidad_fed: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    clues: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    num_recetas_expedidas: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    num_recetas_negadas: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    num_recetas_atendidas_parcialmente: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    num_recetas_atendidas_manera_completa: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    estatus: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
    f_registro :{
      type: 'TIMESTAMP',
      //allowNull: false,
    }
  },
  {
    tableName: 'formulario_clue',
    createdAt: false,
    updatedAt: false,
  }
);
FormularioModel.addFormulario = async (data) => {
  await dbConection.query("BEGIN;");
  try {
    await dbConection.query(
      `INSERT INTO formulario_clue (
        fecha_registro, hora_registro, entidad_fed, clues, num_recetas_expedidas, num_recetas_negadas, num_recetas_atendidas_parcialmente, 
        num_recetas_atendidas_manera_completa
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8
      )`,
      {
        bind: [
          data.fecha_registro,
          data.hora_registro,
          data.entidad_fed,
          data.clues,
          data.num_recetas_expedidas,
          data.num_recetas_negadas,
          data.num_recetas_atendidas_parcialmente,
          data.num_recetas_atendidas_manera_completa,
          
        ],
        type: QueryTypes.INSERT,
      }
    );
    await dbConection.query("COMMIT;");
  } catch (error) {
    await dbConection.query("ROLLBACK;");
    throw error;
  }
};
FormularioModel.updateFormulario = async (data) => {
  
  let id_formulario = data.id_formulario;
  console.log(id_formulario);
  let fecha_registro = data.fecha_registro;
  let entidad_fed = data.entidad_fed;
  let clues = data.clues;
  let num_recetas_expedidas = data.num_recetas_expedidas;
  let num_recetas_negadas = data.num_recetas_negadas;
  let num_recetas_atendidas_parcialmente = data.num_recetas_atendidas_parcialmente;
  let num_recetas_atendidas_manera_completa = data.num_recetas_atendidas_manera_completa;


  await dbConection.query('BEGIN;');
  try {
    // Consulta para actualizar datos en la tabla de usuarios
    const sistema_abasto_institucional = await dbConection.query(
      `UPDATE formulario_clue SET fecha_registro=$2, entidad_fed=$3, clues=$4, num_recetas_expedidas=$5, num_recetas_atendidas_parcialmente=$6, num_recetas_negadas=$7, num_recetas_atendidas_manera_completa=$8 WHERE id_formulario=$1`,
      {
        bind: [id_formulario, fecha_registro, entidad_fed, clues,num_recetas_expedidas,num_recetas_atendidas_parcialmente,num_recetas_negadas,num_recetas_atendidas_manera_completa],
        type: QueryTypes.UPDATE,
      }
    );
    
   

    console.log('Actualizacion guardada');
    await dbConection.query('COMMIT;');
    return true;
  } catch (error) {
    console.error(error);
    await dbConection.query('ROLLBACK;');
    return false;
  }
};

module.exports = FormularioModel;
