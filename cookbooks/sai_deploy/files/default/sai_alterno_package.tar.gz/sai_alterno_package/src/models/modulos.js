const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const modulosModel = dbConection.define('modulos',
    {
        id_modulo: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        titulo: {
            type: DataTypes.STRING,
        },
        activo: {
            type: DataTypes.BOOLEAN,
        },
        fk_id_cat_type_user: {
            type: DataTypes.INTEGER,
        },
        picon: {
            type: DataTypes.STRING,
        },
        visible: {
            type: DataTypes.BOOLEAN,
        },
        f_reg: {
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        },
    },
    {
        createdAt: false,
        updatedAt: false
    }
);
// modulosModel.sync()
// modulosModel.sync({ force: true })
module.exports = modulosModel;