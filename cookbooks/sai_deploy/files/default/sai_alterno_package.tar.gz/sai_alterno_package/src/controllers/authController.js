const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const userModel = require('../models/users');
const ActiveDirectory = require('activedirectory');
const { Op } = require('sequelize');

async function login(req, res) {
  try {
    if (process.env.ACTIVE_DIRECTORY == 'true') {
      return apLoginAD(req, res);
    } else {
      return apLoginNoAd(req, res);
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, error: 1, message: 'Error' });
  }
}

async function apLoginNoAd(req, res) {
  try {
    const user = req.body.user.trim().toLowerCase();
    const pword = req.body.pass;
    const userString = /[@\.]/.test(user) ? user.toLowerCase() : user.toUpperCase();
    const recaptcha = req.body['g-recaptcha-response'] ?? '';

    if (!user || !pword) {
      console.log('No obtuvo datos');
      return res.json({ success: false, msg: 'Ingrese usuario y contraseña' });
    }

    if (process.env.CAPTCHA_MOSTRAR == 'true' && recaptcha == '') {
      return res.json({ success: false, msg: 'Captcha Incorrecto' });
    }

    if (process.env.CAPTCHA_MOSTRAR == 'true') {
      const responseCaptcha = await (
        await fetch(
          'https://www.google.com/recaptcha/api/siteverify',
          {
            method: 'POST',
            body: 'secret=' + process.env.CAPTCHA_SECRET + '&response=' + recaptcha,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
          }
        )
      ).json();

      if (!responseCaptcha.success) {
        console.log('No salió el captcha correctamente');
        return res.json({ success: false, msg: 'Captcha Incorrecto' });
      }
    }

    let userData = await userModel.findOne({ where: { [Op.or]: [{ uname: userString }, { curp: userString }] }, raw: true });

    if (userData == null && !/[@\.]/.test(user)) {
      userData = await userModel.findUserByOldCLUES(userString);
    }

    if (!userData?.activo) {
      return res.json({ success: false, msg: 'Usuario no permitido' });
    } else {
      try {
        const match = await bcrypt.compare(pword, userData.password);
        if (!match) {
          return res.json({ success: false, msg: 'Ingrese usuario y contraseña' });
        } else {
          const token = jwt.sign(
            {
              id_user: userData.id_user,
            },
            process.env.SECRET
          );

          const cookiesOptions = {
            expires: new Date(
              Date.now() + process.env.COOKIE_EXPIRES * 24 * 60 * 1000
            ),
            httpOnly: true,
          };

          res.cookie(process.env.APP_COOKIE_NAME, token, cookiesOptions);
          return res.json({ success: true, msg: '' });
        }
      } catch (error) {
        console.error('Error en bcrypt.compare:', error);
        return res.json({ success: false, msg: 'Error interno' });
      }
    }
  } catch (error) {
    console.error(error);
    return res.json({ success: false, msg: 'Error interno' });
  }
}

async function apLoginAD(req, res) {
  try {
    const user = req.body.user.trim().toLowerCase();
    const pword = req.body.pass;
    const recaptcha = req.body['g-recaptcha-response'] ?? '';

    if (!user || !pword) {
      return res.json({ success: false, msg: 'Ingrese usuario y contraseña[0]' });
    }

    if (process.env.CAPTCHA_MOSTRAR == 'true' && recaptcha == '') {
      return res.json({ success: false, msg: 'Captcha Incorrecto' });
    }

    if (process.env.CAPTCHA_MOSTRAR == 'true') {
      const responseCaptcha = await (
        await fetch(
          'https://www.google.com/recaptcha/api/siteverify',
          {
            method: 'POST',
            body: 'secret=' + process.env.CAPTCHA_SECRET + '&response=' + recaptcha,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
          }
        )
      ).json();

      if (!responseCaptcha.success) {
        return res.json({ success: false, msg: 'Captcha Incorrecto' });
      }
    }

    if (!(/@imssbienestar.gob.mx/.test(user) || /@opdib.gob.mx/.test(user))) {
      return res.json({ success: false, msg: 'Correo no válido' });
    }

    const user_opd = user.replace('@imssbienestar.gob.mx', '@opdib.gob.mx');

    let config = {
      url: 'ldap://172.16.19.1:389',
      baseDN: 'DC=opdib,DC=gob,DC=mx',
      username: user_opd,
      password: pword
    };

    let ad = new ActiveDirectory(config);

    ad.authenticate(user_opd, pword, (err, auth) => {
      if (err) {
        console.error('ERROR: ' + JSON.stringify(err));
        return res.json({ success: false, msg: 'Intente más tarde' });
      }

      if (auth) {
        const attributes = ['userPrincipalName', 'mail', 'sn', 'givenName', 'cn', 'displayName', 'description', 'pager'];
        ad.findUser({ attributes: attributes }, user_opd.split('@')[0], async (err, userAD) => {
          if (err) {
            console.error('ERROR: ' + JSON.stringify(err));
            return res.json({ success: false, msg: 'Intente más tarde' });
          } else {
            let userData = await userModel.findOne({ where: { uname: userAD.mail } });

            if (userData?.email == user) {
              const token = jwt.sign(
                {
                  id_user: userData.id_user,
                },
                process.env.SECRET
              );

              const cookiesOptions = {
                expires: new Date(
                  Date.now() + process.env.COOKIE_EXPIRES * 24 * 60 * 1000
                ),
                httpOnly: true,
              };

              res.cookie(process.env.APP_COOKIE_NAME, token, cookiesOptions);
              return res.json({ success: true, msg: 'Inicio Correcto' });
            } else {
              return res.json({ success: false, msg: 'Ingrese usuario y contraseña[1]' });
            }
          }
        });
      } else {
        return res.json({ success: false, msg: 'Ingrese usuario y contraseña[2]' });
      }
    });
  } catch (error) {
    console.error(error);
    return res.json({ success: false, msg: 'Intente más tarde' });
  }
}

async function psw(req, res) {
  try {
    const id_user = req.usdata.id_user;
    const pass = req.body.pass;
    const passConf = req.body.passConf;
    let passtr = pass.toString();

    const longitud = 8;
    const mayusculas = /[A-ZÑ]+/;
    const minusculas = /[a-zñ]+/;
    const numero = /\d+/;
    const caracteresEspeciales = /[|°¬!'#$%&/()='?\\¿¡@´¨+*~{[^}\]`<>,;.:\-_]+/;

    if (
      passtr == '' ||
      passtr != passConf.toString() ||
      pass.length < longitud ||
      !mayusculas.test(passtr) ||
      !minusculas.test(passtr) ||
      !numero.test(passtr) ||
      !caracteresEspeciales.test(passtr)
    ) return;

    const saltRounds = 10;
    const salt = bcrypt.genSaltSync(saltRounds);
    const hashedPass = bcrypt.hashSync(pass, salt);

    await userModel.update(
      { campass: true, upass: hashedPass },
      { where: { id_user: id_user } }
    );

    return res.redirect('/');
  } catch (error) {
    console.log('Error: ' + error);
  }
}

function logout(req, res) {
  res.clearCookie(process.env.APP_COOKIE_NAME);
  return res.redirect('/');
}

module.exports = {
  login,
  psw,
  logout,
};

