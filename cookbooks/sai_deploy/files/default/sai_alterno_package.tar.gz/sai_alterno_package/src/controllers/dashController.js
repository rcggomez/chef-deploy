const jwt = require('jsonwebtoken');
const userModel = require('../models/users');
const cat_type_usersModel = require('../models/cat_type_users');
const {promisify} = require('util');
const WS = require('../util/WebServices')
// const { Sequelize, DataTypes } = require('sequelize');
// const sub_moduloModel = require('../models/sub_modulo');
const CatalogModel = require('../models/CatalogModel');


async function inicio(req,res){


  try {
    if (!req.cookies[process.env.APP_COOKIE_NAME]){
  
      res.render('index', {
          alert: false , 
        });
        return;
    }
    const decoded = await promisify(jwt.verify)(req.cookies[process.env.APP_COOKIE_NAME], process.env.SECRET);

    if(!decoded.id_user){
      res.render('index', {
        alert: false , 
      });
      return;
    }
    let data = await userModel.findOne({ where: { id_user: decoded.id_user } });
    req.usdata = data.dataValues;
    req.usdata.type_user = global.catalogos.cat_type_users.find(e=>e.id_cat_type_users==data.fk_id_cat_type_users).type_user;
    req.usdata.modulos = await CatalogModel.getPermisos(data.id_user);
    // req.usdata.estado = global.catalogos.cat_entidad_federativa.find(e=>e.id_estado==data.fk_id_estado).estado;
    
    
    if(process.env.ACTIVE_DIRECTORY!='true'&&(req.usdata.campass==false)){
      return res.render('psw');
    } 
    return res.render('inicio',{
      alert: false,
      alertTitle: 'Bienvenido',
      alertMessage: 'Ingreso correcto',
      ...req.usdata,
      ultimaActualizacion: (new Date).toLocaleString('es-MX'),
    });
    //Si algo sale mál renderizamos el index, lo unico que podría causar el bucle es que se elimine el usuario de la tabla mientras la cookie sigue activa.
  } catch (error) {
    console.error(error);
    res.render('index', {
      alert: false , 
    });
  }
}

async function savecdr(req,res){

  try {
    

    const token = req.cookies[process.env.APP_COOKIE_NAME];
    const usuario = jwt.verify(token, process.env.SECRET);
    const id_user = usuario.id_user;

    console.log(id_user);

    const blobServiceClient = BlobServiceClient.fromConnectionString(
      process.env.BLOB_CONNECTION
    );
    const containerName = process.env.BLOB_CONTAINER;
    const containerClient = blobServiceClient.getContainerClient(containerName);


    const images = ['img_selfie'];
    const blobPath = 'persona/' + id_user;
    let newFile;
    let tipo_doc = 0;

    for (const imgField of images) {
      const image = req.files[imgField][0];

      const fileSizeInBytes = image.size;
      const fileType = image.mimetype;
      const fileExtension = image.originalname.split('.').pop();
      console.log('image.originalname' + image.originalname);
      switch (imgField) {
        case 'img_selfie':
          tipo_doc = 1;
          break;
      }

      const blobName = blobPath + '/' + `${Date.now()}-${imgField}-${image.originalname}`;
            
      newFile = new archivosModel({
        fk_id_user: id_user,
        fk_id_tipo_doc: tipo_doc,
        nombre_archivo: blobName,
        tamanio_archivo: fileSizeInBytes,
        tipo:fileType,
        fk_id_cat_tipo_archivo: tipo_doc,
      });

      resulFile = await newFile.save();

      if (resulFile) {
        const blockBlobClient = containerClient.getBlockBlobClient(blobName);
        await blockBlobClient.upload(image.buffer, image.size);
      }

      res.json({ success: true, msg: 'Éxito al guardar' });
    }

  } catch (error) {
    console.log(error);
    res.json({ success: false, msg: 'Intente más tarde' });

  }



}

module.exports = {
    inicio,
    savecdr,
};
  