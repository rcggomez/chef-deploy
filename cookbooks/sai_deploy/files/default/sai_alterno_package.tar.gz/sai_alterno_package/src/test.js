const dbConection = require('./config/postgressdb');
const cat_clues = require('./models/cat_clues')
const cat_estados = require('./models/cat_estados');
const rel_users_sub_moduloModel = require('./models/rel_users_sub_modulo');
const usersModel = require('./models/users')
const bcrypt = require("bcrypt");

/*const exceljs = require('exceljs');
const path = require('path')

let datafile = path.join(__dirname, "/relacion_variables_preguntas.xlsx");
const workbook = new exceljs.Workbook(); 
workbook.xlsx.readFile(datafile)
    .then(function() {
        let sh = workbook.getWorksheet("Sheet1");
        for(let i=1;i<=sh.actualRowCount;i++){
            if(sh.getRow(i).getCell(1).value==column1Item){
                data1 = sh.getRow(i).getCell(2).value;
            }
        }
    });

console.log(__dirname);*/


async function seederData(){
    const clues = await cat_clues.findAll()
    const entidades = await cat_estados.findAll()
    let contador = 0

    console.log("Entidades: " + entidades.length)
    console.log("Clues: " + clues.length)

    const passtemp = '12345678';

    const saltRounds = 10;
    const salt = bcrypt.genSaltSync(saltRounds);
    const passws = passtemp;
    const hashedPass = bcrypt.hashSync(passws, salt);

    console.log(hashedPass);

    await Promise.all(clues.map(async element => {
        item = element.dataValues

        //console.log(item['ENTIDAD FEDERATIVA'])
        let estado = entidades.filter(entidad => ((entidad.estado).normalize("NFD").replace(/[\u0300-\u036f]/g, "")).toUpperCase() == item['ENTIDAD FEDERATIVA']);
        //console.log(estado[0].dataValues.id_estado)
        
        if(estado.length>0){
            contador++
            //console.log(estado[0].dataValues.id_estado)
            // console.log(item.clues+"-");
            let usuario = await usersModel.create({
                uname: item.clues,
                upass: hashedPass,
                fk_id_cat_type_users: 3,
                nombre: item['NOMBRE UNIDAD Y CLUES'].replace(`${item.clues} - `, ""),
                primer_apellido:null,
                segundo_apellido:null,
                email:null,
                telefono_fijo:null,
                telefono_celular:null,
                curp:null,
                rfc:null,
                fk_id_estado: estado[0].dataValues.id_estado,
                fk_id_municipio: null,
                campass: true,
                activo:true
            })

            await rel_users_sub_moduloModel.create({
                fk_id_user:usuario.dataValues.id_user,
                fk_id_sub_modulo:2,
                vigente:true,
                f_no_vigente:null
            })

        }else{
            if(item['ENTIDAD FEDERATIVA'] == 'ESTADO DE MEXICO'){
                contador++
                let usuario = await usersModel.create({
                    uname: item.clues,
                    upass: hashedPass,
                    fk_id_cat_type_users: 3,
                    nombre: item['NOMBRE UNIDAD Y CLUES'].replace((item.clues + " - "), ""),
                    primer_apellido:null,
                    segundo_apellido:null,
                    email:null,
                    telefono_fijo:null,
                    telefono_celular:null,
                    curp:null,
                    rfc:null,
                    fk_id_estado: 15,
                    fk_id_municipio: null,
                    campass: true,
                    activo:true
                })

                await rel_users_sub_moduloModel.create({
                    fk_id_user:usuario.dataValues.id_user,
                    fk_id_sub_modulo:2,
                    vigente:true,
                    f_no_vigente:null
                })
            }
        }
    }))

    console.log("SE INSERTARON: " + contador + " REGISTROS.")
}

seederData()