const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes, QueryTypes } = require('sequelize');

const usersModel = dbConection.define('users',
  {
    id_user: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    uname: {
      type: DataTypes.STRING,
    },
    upass: {
      type: DataTypes.STRING,
    },
    fk_id_cat_type_users: {
      type: DataTypes.INTEGER,
      //allowNull: false,
      references: {
        model: 'cat_type_users',
        key: 'id_cat_type_users',
      },
      onDelete: 'RESTRICT',
    },
    nombre: {
      type: DataTypes.STRING,
    },
    primer_apellido: {
      type: DataTypes.STRING,
    },
    segundo_apellido: {
      type: DataTypes.STRING,
    },
    email: {
      type: DataTypes.STRING,
    },
    telefono_fijo: {
      type: DataTypes.STRING,
    },
    telefono_celular: {
      type: DataTypes.STRING,
    },
    curp: {
      type: DataTypes.STRING,
    },
    rfc: {
      type: DataTypes.STRING,
    },
    fk_id_estado: {
      type: DataTypes.INTEGER,
    },
    fk_id_municipio: {
      type: DataTypes.INTEGER,
    },
    clue_relacionada_produccion: {
      type: DataTypes.STRING,
    },
    campass: {
      type: DataTypes.BOOLEAN,
    },
    activo: {
      type: DataTypes.BOOLEAN,
    },
    f_ingreso: {
      type: 'TIMESTAMP',
      allowNull: false,
      defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
    },
  },
  {
    createdAt: false,
    updatedAt: false,
  }
);
usersModel.addUser = async (data) => {
  console.log('data', data);
  let uname = data.email;
  let upass = data.hashedPass;
  let fk_id_cat_type_users = data.tipo;
  let nombre = data.nombre;
  let primer_apellido = data.primer_apellido;
  let segundo_apellido = data.segundo_apellido;
  let email = data.email;
  let telefono_fijo = data.telefono_fijo;
  let telefono_celular = data.telefono_celular;
  let curp = data.curp;
  let rfc = '';
  let fk_id_estado = data.fk_id_estado;
  let clue_relacionada_produccion = data.clue_relacionada_produccion || null;
  console.log('clue_relacionada_produccion', clue_relacionada_produccion);
  await dbConection.query('BEGIN;');
  try {
    await dbConection.query(
      'INSERT INTO users(uname,upass,fk_id_cat_type_users,nombre,primer_apellido,segundo_apellido,email,telefono_fijo,telefono_celular,curp,rfc,fk_id_estado,clue_relacionada_produccion,campass,activo) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,false,true)',
      {
        bind: [
          uname,
          upass,
          fk_id_cat_type_users,
          nombre,
          primer_apellido,
          segundo_apellido,
          email,
          telefono_fijo,
          telefono_celular,
          curp,
          rfc,
          fk_id_estado,
          clue_relacionada_produccion,
        ],
        type: QueryTypes.INSERT,
      }
    );
    // let sm_result = '';
    // console.log('data.tipo',data.tipo);
    const sm_result = await dbConection.query(
      `INSERT INTO rel_users_sub_modulo(fk_id_user,fk_id_sub_modulo) SELECT currval('users_id_user_seq'), SM.id_sub_modulo
            FROM cat_type_users CTU
            JOIN sub_modulo SM ON ( SM.id_sub_modulo = ANY(CTU.default_sub_modules) AND CTU.id_cat_type_users=$1 )
            WHERE SM.visible=true
            ORDER BY id_sub_modulo`,
      {
        bind: [fk_id_cat_type_users],
        type: QueryTypes.INSERT,
      }
    );
    await dbConection.query('COMMIT;');
    return true;
  } catch (error) {
    console.error(error);
    await dbConection.query('ROLLBACK;');
    return false;
  }
};

usersModel.updateUser = async (data) => {
  
  let id_user = data.id_user;
  let email = data.email;
  let telefono_celular = data.telefono_celular;
  let telefono_fijo = data.telefono_fijo;
  let permisos = data.permisos;
  let permisosUsuario = data.permisosUsuario;
  let todosPermisosPresentes = data.todosPermisosPresentes;


  await dbConection.query('BEGIN;');
  try {
    // Consulta para actualizar datos en la tabla de usuarios
    const actualizarTablaUsuarios = await dbConection.query(
      `UPDATE users SET email=$2, telefono_celular=$3, telefono_fijo=$4 WHERE id_user=$1`,
      {
        bind: [id_user, email, telefono_celular, telefono_fijo],
        type: QueryTypes.UPDATE,
      }
    );
    

    // Al menos un permiso del usuario no está presente en los permisos
    if ( todosPermisosPresentes == false ){
      // Consulta para actualizar los módulos antiguos
      const actualizarModulosAntiguos = await dbConection.query(
        `UPDATE rel_users_sub_modulo SET vigente=false, f_no_vigente=NOW() WHERE fk_id_user=$1`,
        {
          bind: [id_user],
          type: QueryTypes.UPDATE,
        }
      );
      // Consulta para insertar nuevos módulos}
      const registrarNuevosModulos = await dbConection.query(
        `INSERT INTO rel_users_sub_modulo(fk_id_user,fk_id_sub_modulo) 
        SELECT $1, id_sub_modulo 
        FROM sub_modulo 
        WHERE id_sub_modulo IN(${permisos}) AND visible=true 
        ORDER BY id_sub_modulo`,
        {
          bind: [id_user],
          type: QueryTypes.INSERT,
        }
      );
    } 

    console.log('Actualizacion guardada');
    await dbConection.query('COMMIT;');
    return true;
  } catch (error) {
    console.error(error);
    await dbConection.query('ROLLBACK;');
    return false;
  }
};

usersModel.findUserByOldCLUES = async (oldCLUES) => {
  try {
    console.log('entrando oldCLUES');
    let user = await dbConection.query('SELECT U.* FROM users U JOIN clues_actualizadas CA ON CA.clues = U.uname WHERE CA.clues_ssa = $1',{
      bind: [oldCLUES],
      type: QueryTypes.SELECT
    })
    return user[0]
  } catch(e){
    console.error(e);
    return null;
  }
}

usersModel.getOldCLUES = async (id_user) => {
  try {
   let user = await dbConection.query('SELECT U.*,CA.clues_ssa FROM users U JOIN clues_actualizadas CA ON CA.clues = U.uname WHERE U.id_user = $1',{
      bind: [id_user],
      type: QueryTypes.SELECT
    })
    return user[0]
  } catch(e){
    console.error(e);
    return null;
  }
}

module.exports = usersModel;
