const { Sequelize } = require('sequelize');
require('dotenv').config();

// Asegúrate de que las variables de entorno estén cargadas
console.log('DB Config:', {
  database: process.env.PGDB_NAME,
  user: process.env.PGDB_USER,
  password: typeof process.env.PGDB_PASSWORD, // Verifica el tipo
  host: process.env.PGDB_HOST,
  port: process.env.PGDB_PORT
});

const sequelize = new Sequelize({
  database: process.env.PGDB_NAME,
  username: process.env.PGDB_USER,
  password: String(process.env.PGDB_PASSWORD), // Conversión explícita a string
  host: process.env.PGDB_HOST,
  port: process.env.PGDB_PORT,
  dialect: 'postgres',
  dialectOptions: {
    ssl: false // Desactiva SSL si no lo necesitas
  },
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  logging: console.log // Habilita logging temporal para diagnóstico
});

// Test de conexión mejorado
(async () => {
  try {
    await sequelize.authenticate();
    console.log('Conexión a PostgreSQL exitosa');
    
    // Opcional: Verifica que puedes hacer una consulta simple
    const [result] = await sequelize.query('SELECT version()');
    console.log('Versión de PostgreSQL:', result[0].version);
  } catch (error) {
    console.error('Error de conexión a PostgreSQL:', error.original || error);
    process.exit(1);
  }
})();

module.exports = sequelize;
