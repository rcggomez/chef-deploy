const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const produccion = dbConection.define('produccion',
    {
        id_produccion:{
            type:  DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        entidad_fed: {
            type: DataTypes.INTEGER,
            //allowNull: false,
            references: {
                model: 'cat_estados',
                key: 'id_estado',
            },
            onDelete: 'RESTRICT',
        },
        clues: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        fecha_preescripcion: {
            type: DataTypes.DATE,
            defaultValue: true
        },
        fecha_surtimiento: {
            type: DataTypes.DATE,
            defaultValue: true
        },
        fecha_creacion:{
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: 'NOW()',
        },
        estatus: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue:true
        }
    },
    {
        tableName: 'produccion', 
        freezeTableName: true ,
        createdAt: false,
        updatedAt: false
    });

// FormularioUnidadHospitalariaModel.sync({force:true})
// produccion.removeAttribute('id_produccion');

module.exports = produccion;
