// class Util {

//     constructor() {
    
//     }
//  validacionCamposRenapo = (item) => {

//         let result = "";
      
//         if (item != undefined) {
//           result = item;
//         }else{
//           result=" "
//         }
      
//         return result;
//       };
// }

// module.exports = Util;

/**
 * @abstract El proposito de esta constante es para no declarar una y otra vez un formateador de fecha larga.
 * En realidad no es necesaario, sin embargo puede servie como ejemplo para otros formateadores
 */
const FormateadorDeFechas = new Intl.DateTimeFormat('es-Mx',{ day: 'numeric', month: 'long', year: 'numeric' });
function genCode(){
  const caracteresPermitidos = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';//0, 1, I, L, Ñ, O: No están dado a que pueden generar confuciones
  let cadenaAleatoria = '';

  for (let i = 0; i < 5; i++) {
    const caracterAleatorio = caracteresPermitidos.charAt(
      Math.floor(Math.random() * caracteresPermitidos.length)
    );
    cadenaAleatoria += caracterAleatorio;
  }

  return cadenaAleatoria;
}
/**
 * 
 * @param {string} fechaNac 
 * @returns {number}
 */
function calcularEdad(fechaNac){
  
  const [day, month, year] = fechaNac.split('/').map(Number);
  if (isNaN(day) || isNaN(month) || isNaN(year)) {
      throw new Error('Formato de fecha no válido.');
      //return 0;
  }

  const monthM1 = month - 1;

  const birthDate = new Date(year, monthM1, day);

  if (isNaN(birthDate.getTime())) {
      throw new Error('Error en calculo de Edad: isNaN(birthDate.getTime())==true ');
  }
  const currentDate = new Date();
  
  const edad = currentDate.getFullYear() - birthDate.getFullYear();
  if (
    birthDate.getMonth() > currentDate.getMonth() ||
    (birthDate.getMonth() === currentDate.getMonth() &&
      birthDate.getDate() > currentDate.getDate())
  ) {
    return edad - 1;
  } else {
    return edad;
  }
}
/**
 * 
 * @param {*} message Mensaje a Enviar
 * @returns 
 */
async function messageTelegram(message){

  let response = { 'code': 200, message: null, model: null }

  try {
      const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
      const BOT_GROUP_ID = process.env.TELEGRAM_BOT_GROUP_ID;
      const TelegramBot = require('node-telegram-bot-api');
      const bot = new TelegramBot(BOT_TOKEN/*, { polling: true }*/);

      let res = await bot.sendMessage(BOT_GROUP_ID, message);
      response.code = 200;

  } catch (e) {
      console.log(e);
      response.code = 500;
      response.message = JSON.stringify(e);
  }

  return response;
}
/**
 * @abstract Función para el envio de SMS con la api de SMS Masivos
 * @param {string} message Mensaje a enviar
 * @param {number} number Numero destinatario
 * @param {number} sandbox 1 para pruebas 0 para envio real, por defecto 0preparado para producción
 */
async function enviarSMS(message,number,sandbox=0){
  const apikey = process.env.SMSMASIVOS_APIKEY;
  if(apikey=='') return {
      success: false,
      error: 'No apikey'
  }
  const url ='https://api.smsmasivos.com.mx/sms/send';
  const infoRequest = {
      message: message,
      numbers: number,
      country_code: '52',
      sender: 'IMSS-BIENESTAR',
      sandbox: sandbox
  };
  return fetch(
      url,
      {
          method:'POST',
          headers: { apikey: apikey },
          body: (new URLSearchParams(infoRequest)).toString()
      }
  ).then(async (response)=>{
      if( response.ok && response.status==200){
          return await response.json();
      } else{
          return {
              success: false,
              message: 'Mensaje no enviado',
              status: response.status
          }
      }
  }).catch(error=>{
      console.error('--->>>sms.enviarSMS');
      console.error(error);
      console.error('sms.enviarSMS<<<---');
      return {
          success: false,
          message: 'Mensaje no enviado',
          error: error
      }
  });
}

/**
 * @param {Object} data
 * data = {to,to_name,subject,body [,isHTml] [,attachments] }
 * @param {String} data.to direccion del correo destinatario
 * @param {String} data.to_name nombre del correo destinatario
 * @param {String} data.subject asunto del correo
 * @param {String} data.body cuerpo del correo
 * @param {boolean} data.isHTml bandera para tratar al cuerpo como html
 * @param {Array} data.attachments Arreglo con los attachments
 */
async function enviarEmail(data){
  // Etapa de Validaciones
  if(
    process.env.MAILER_HOST==''
    || process.env.MAILER_HOST==''
    || process.env.MAILER_PORT==''
    || process.env.MAILER_USER==''
    || process.env.MAILER_PASS==''
    || process.env.MAILER_FROM_NAME==''
    || process.env.MAILER_FROM_ADRESS==''
  ) throw new Error('Error en la configuración de MAILER');
  if(
    (data?.to??'')==''
    || (data?.to_name??'')==''
    || (data?.subject??'')==''
    || (data?.body??'')==''
  ) throw new Error('Datos requeridos para Email no ingresados');
  // Etapa de inicializaciones
  const nodemailer = require('nodemailer');
  const mailObject = {
    from: '"'+process.env.MAILER_FROM_NAME+'" <'+process.env.MAILER_FROM_ADRESS+'>',
    to: '"'+data.to_name+'" <'+data.to+'>',
    subject: data.subject
  };
  if(data?.isHTml==true){
      mailObject.html=data.body
  } else{
      mailObject.text = data.body;
  }
  if(data.attachments != undefined && data?.attachments != null && Array.isArray(data.attachments)){
      mailObject.attachments=data.attachments
  }
  // Etapa de envio
  const transporter = nodemailer.createTransport({
    host: process.env.MAILER_HOST,
    port: process.env.MAILER_PORT,
    secure: process.env.MAILER_PORT=='465', // Use `true` for port 465, `false` for all other ports
    auth: {
      user: process.env.MAILER_USER,
      pass: process.env.MAILER_PASS,
    },
  });
  return (await transporter.sendMail(mailObject));
}

function completarCedulaProfesional(cedulaProfesional){
  let agregarCeros = '';
  let iteraciones = 0
  try{
    iteraciones = 10 - cedulaProfesional.length
    if(iteraciones > 0 && cedulaProfesional){
      for(let i = 0; i < iteraciones; i++){
        agregarCeros += '0'
      }
    }

    return agregarCeros + cedulaProfesional
  
  }catch(error){
    return cedulaProfesional
  }
}

module.exports = {
  genCode,
  calcularEdad,
  messageTelegram,
  enviarSMS,
  enviarEmail,
  FormateadorDeFechas,
  completarCedulaProfesional
}
