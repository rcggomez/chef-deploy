const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const cat_servicios = dbConection.define('cat_servicios',
    {
        id:{
            type:  DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement:true
        },
        descripcion:{
            type: DataTypes.STRING
        },
        tipo:{
            type: DataTypes.STRING
        },
        estatus:{
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        
    },
    {
        createdAt: false,
        updatedAt: false
    }
);

module.exports = cat_servicios;