const dbConection = require('../config/postgressdb');
const userModel = require("../models/users");
const produccionModel = require("../models/produccion");
const produccionDetalleServiciosModel = require("../models/recetasDetalleServicios");
const getNombreEntidad = require('../util/diccionario');
const { generarXLSFormulario, generarXLSFormularioProduccion } = require("../util/generarExcel");
const cat_estados = require("../models/cat_estados");
const CatalogModel = require("../models/CatalogModel");
const catMedicamentos = require("../models/cat_medicamentos");
const FormularioModel = require("../models/FormularioModel");
const bcrypt = require("bcrypt");
const fs = require("fs");
const path = require("path");
const { renapoConsultarCurp } = require("../util/WebServices");
const { genCode, completarCedulaProfesional } = require("../util/util");
const { enviarEmail } = require("../util/util");
const PGconn = require("../config/postgressdb");
const { stringify } = require("querystring");
const { Op } = require('sequelize'); // Asegúrate que esto esté al principio de tu archivoconst sequelizeConfig = require("../config/postgressdb");
const cat_clues = require("../models/cat_clues");
const cat_medicamentos = require("../models/cat_medicamentos");
const recetas = require("../models/recetas");
const recetasDetalleMedicamento = require("../models/recetasDetalleMedicamento");
const { generarXLSFormularioRecetas } = require("../util/generarExcel");
const bitacora = require("../models/bitacora");
const cat_servicios = require('../models/cat_servicios');
const recetasDetalleServicios = require('../models/recetasDetalleServicios');
const produccion = require('../models/produccion');
const cat_clues_produccion = require('../models/cat_clues_produccion');

async function formsProduccion(req, res) {
  let usuarios = await userModel.findAll();
  let estados = global.catalogos.cat_entidad_federativa;
  let formulario = []
  // await FormularioModel.findAll({
  //   where: { estatus: true },
  // });
  let clue = "";

  if (req.usdata.fk_id_cat_type_users == 5) { // Filtracion de mostrar todo de la misma clue

    // formulario = await FormularioModel.findAll({
    //   where: { entidad_fed: String(req.usdata.fk_id_estado), clues: String(req.usdata.uname),estatus: true },

    // });

    estados = await cat_estados.findAll({ where: { id_estado: req.usdata.fk_id_estado } });
    clue = await cat_clues_produccion.findAll({ where: { clues: req.usdata.clue_relacionada_produccion } });
  } else if (req.usdata.fk_id_cat_type_users == 2) { // filtracion de mostrar visor estatal
    // formulario = await FormularioModel.findAll({
    //   where: { entidad_fed: String(req.usdata.fk_id_estado),estatus: true  },

    // });
    estados = await cat_estados.findAll({ where: { id_estado: req.usdata.fk_id_estado } });
    clue = await cat_clues_produccion.findAll({ where: { fk_id_cat_type_users: String('3'), fk_id_estado: String(req.usdata.fk_id_estado) } });

  }
  else if (req.usdata.fk_id_cat_type_users == 4 || req.usdata.fk_id_cat_type_users == 1) { // filtracion de mostrar visor general y 
    // formulario = await FormularioModel.findAll({
    //   where: { estatus: true },
    // });
    estados = global.catalogos.cat_entidad_federativa;
    clue = await cat_clues_produccion.findAll();
  }

  const formularioMapped = formulario.map(item => {
    return {
      ...item.dataValues,
      entidad_fed: getNombreEntidad(item.entidad_fed)
    };
  });
  // } else {
  // formulario = await FormularioModel.findAll();

  let buffer;
  if (formulario == null) {
    buffer = "";
    console.log("No hay formulario con datos");
    formulario = [];
  } else {
    // console.log(formulario);
    buffer = await generarXLSFormulario(formulario);

  }

  let servicios = await cat_servicios.findAll();
  // buffer: buffer.toString("base64"),


  // console.log(formulario);
  try {

    res.render("formularioProduccion", {
      ...req.usdata,
      formulario: formularioMapped,
      cat_type_users: global.catalogos.cat_type_users,
      cat_entidades_admins: estados, //global.catalogos.cat_entidades_admins,
      sub_modulos: global.catalogos.sub_modulo, //sub_modulos,
      listaUsuarios: usuarios,
      directorio_activo: process.env.ACTIVE_DIRECTORY,
      buffer: buffer.toString("base64"),
      clues: clue,
      servicios: servicios
    });
  } catch (error) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.adduser  ::' + error.message);
    console.error("--->>> usuariosController.formsRecetas ");
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: "Error" });
  }
}

async function obtenerFormulariosProduccion(req, res) {
  const { draw, start, length } = req.body;
  const searchValue = req.body.search.value;

  // Convertir a números enteros para que Sequelize los use correctamente
  const offsetValue = parseInt(start, 10);
  const limitValue = parseInt(length, 10);

  const where = { estatus: true }; // Condición base de estatus

  // Lógica para aplicar condiciones de usuario (fk_id_cat_type_users)
  if (req.usdata.fk_id_cat_type_users == 5) {
    where.clues = String(req.usdata.clue_relacionada_produccion); // Asumo que aquí no necesitas Op.or como en el otro caso
  } else if (req.usdata.fk_id_cat_type_users == 2) {
    where.entidad_fed = String(req.usdata.fk_id_estado);
  }

  // Aplicar la búsqueda global (searchValue) si existe
  if (searchValue) {
    where[Op.or] = [
      // Asegúrate que estos nombres de columnas existan en tu tabla 'recetas'
      { id_produccion: { [Op.like]: `%${searchValue}%` } },
    ];
  }

  try {
    // Primero, obtener el conteo total de registros sin la búsqueda global
    // Esto es para 'recordsTotal' en DataTables
    const totalCountWhere = { estatus: true };
    if (req.usdata.fk_id_cat_type_users == 5) {
      totalCountWhere.clues = String(req.usdata.clue_relacionada_produccion);
    } else if (req.usdata.fk_id_cat_type_users == 2) {
      totalCountWhere.entidad_fed = String(req.usdata.fk_id_estado);
    }
    const totalCount = await produccionModel.count({ where: totalCountWhere });

    // Luego, obtener los registros paginados y filtrados
    // 'count' aquí será el 'recordsFiltered'
    console.log('where', where);
    const { count: filteredCount, rows: paginatedFormulariosRecetas } = await produccionModel.findAndCountAll({
      where: where, // Se aplican todas las condiciones aquí, incluyendo searchValue y las de usuario
      order: [['id_produccion', 'ASC']], // Tu ordenamiento predeterminado
      offset: offsetValue,            // El inicio de la página
      limit: limitValue,              // El número de registros por página
    });

    // Mapear y transformar los datos (si es necesario)
    const dataFormatted = paginatedFormulariosRecetas.map(item => ({
      ...item.dataValues,
      entidad_fed: getNombreEntidad(item.entidad_fed) // Asegúrate que getNombreEntidad esté disponible
    }));

    const respuesta = {
      draw: draw,
      recordsTotal: totalCount,      // Conteo total sin búsqueda global
      recordsFiltered: filteredCount, // Conteo después de aplicar filtros y búsqueda
      data: dataFormatted             // Los registros de la página actual
    };

    res.json(respuesta);
  } catch (error) {
    // Manejo de errores para depuración
    console.error('Error en obtenerFormulariosRecetas:', error.message);
    console.error('Stack Trace:', error.stack);
    res.status(500).json({ error: 'Error interno del servidor al obtener formularios de recetas.' });
  }
}

async function obtenerRecetaProduccion(req, res) {
  try {
    let response = { success: false, msg: '', data: [] };
    const { id_produccion } = req.body;
    const produccion = await produccionModel.findOne({
      where: { id_produccion: id_produccion }
    });
    const servicios = await recetasDetalleServicios.findAll({
      where: { fk_id_produccion: id_produccion, estatus: true }
    });
    const detallesServicios = await cat_servicios.findAll();
    const serviciosMapped = servicios.map(item => {
      const servicio = detallesServicios.find(med => med.id === item.fk_id_servicio);
      return {
        ...item.dataValues, // Incluye todas las propiedades de recetasDetalleMedicamento (incluyendo cantidad_faccionado)
        descripcion: servicio.descripcion,
        tipo: servicio.tipo
      };
    });
    response.success = true;
    response.data = { produccion, medicamentos: serviciosMapped };
    res.json(response);
  } catch (error) {
    console.error("--->>> usuariosController.obtenerReceta ");
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: "Error al obtener la receta" });
  }
}

async function editarRecetaProduccion(req, res) {
  console.log(req.body);
  let bitacoraEstatus = 2;
  let bitacoraRegistroAnteriorRecetas = await produccion.findByPk(parseInt(req.body.id_produccion));
  let bitacoraRegistroAnteriorRecetasDetalladas = await recetasDetalleServicios.findOne({ where: { fk_id_produccion: req.body.id_produccion }, raw: true });
  let bitacoraRegistroAnterior = { ...bitacoraRegistroAnteriorRecetas.dataValues, ...bitacoraRegistroAnteriorRecetasDetalladas };
  console.log(bitacoraRegistroAnterior);
  const { id_produccion, entidad_fed, clues, fecha_prescripcion, fecha_surtimiento, servicio } = req.body
  let response = { success: false, msg: '', data: [] }
  try {
    let receta = await produccion.findOne({
      where: { id_produccion: id_produccion }
    });

    let fecha_creacion_receta = new Date(receta.fecha_creacion);
    fecha_creacion_receta.setHours(fecha_creacion_receta.getHours() - 6);
    let fecha_actual = new Date();
    let type_user = req.usdata.type_user;
    if (!verificacionEditableFechas(fecha_creacion_receta, fecha_actual, type_user)) {
      response.msg = 'No se puede editar el formulario, han pasado más de 3 días desde su creación.'
      return res.status(200).json(response)
    }
    if (!receta) {
      response.msg = 'No se encontró el formulario de producción.'
      return res.status(404).json(response)
    }
    let medicamentos = Object.values(JSON.parse(servicio))
    if (medicamentos) {
      let cadena = ''
      let contador = 0
      for (item of medicamentos) {
        contador++
        if (!item.id || !item.cantidad_medicamento_recetado || !item.cantidad_medicamento_surtido) {
          cadena += `Todos los campos de servicios suministrados de la fila ${contador} son requeridos.<br>`
        }

        if (item.cantidad_medicamento_recetado <= 0 /*|| item.cantidad_medicamento_surtido <= 0*/) {
          cadena += `El valor debe ser mayor a 0, en servicios, en la fila ${contador}.<br>`
        }
      }

      const vistos = new Set();
      const duplicados = medicamentos.filter((objeto, item) => {
        if (objeto.id.trim()) {
          const clave = objeto.id;
          if (vistos.has(clave)) {
            cadena += `El servicio de la fila ${item + 1} ya existe, favor de seleccionar otra opcion.<br>`
          }
          vistos.add(clave);
          return false;
        }
      });

      if (cadena) {
        response.msg = cadena
        return res.status(200).json(response)
      }
    }

    await PGconn.query('BEGIN')

    //eliminar los medicamentos de la receta
    let detallesMedicamentos = await recetasDetalleServicios.findAll({
      where: { fk_id_produccion: id_produccion }
    });

    for (detalle of detallesMedicamentos) {
      detalle.estatus = false
      await detalle.save()
    }

    if (medicamentos) {
      for (item of medicamentos) {
        await recetasDetalleServicios.create({
          fk_id_produccion: receta.id_produccion,
          fk_id_servicio: item.id,
          cantidad_expedida: item.cantidad_medicamento_surtido,
          cantidad_receptida: item.cantidad_medicamento_recetado,
          estatus: true
        })
      }
    }

    receta.entidad_fed = entidad_fed
    console.log(clues);
    receta.clues = clues
    receta.fecha_preescripcion = fecha_prescripcion
    receta.fecha_surtimiento = fecha_surtimiento
    await receta.save()
    // console.log(receta);
    await PGconn.query('COMMIT')
    // let bitacoraRegistroActualrRecetas = await produccion.findByPk(parseInt(req.body.id_produccion));
    // let bitacoraRegistroActualrRecetasDetalladas = await recetasDetalleServicios.findOne({ where: { fk_id_produccion: req.body.id_produccion }, raw: true });
    // let bitacoraRegistroActual = { ...bitacoraRegistroActualrRecetas.dataValues, ...bitacoraRegistroActualrRecetasDetalladas };
    // console.log(bitacoraRegistroActual);
    // let bitacoraCreate = await bitacora.create({
    //   fk_id_responsable: req.usdata.id_user,
    //   fk_id_registro_modificado: id_produccion,
    //   registro_antes: JSON.stringify(bitacoraRegistroAnterior),
    //   registro_despues: JSON.stringify(bitacoraRegistroActual),
    //   fk_id_estatus: bitacoraEstatus
    // });

    // await recetas.increment('numero_cambios', { by: 1, where: { id_produccion: id_produccion } });
    response.success = true
    response.msg = 'La produccion se actualizó correctamente.'
    return res.status(200).json(response)
  } catch (error) {
    console.log(error)
    response.msg = 'Error al guardar registro'
    await PGconn.query('ROLLBACK')
    return res.status(500).json(response)
  }
}

function verificacionEditableFechas(fecha_creacion_receta, fecha_actual, type_user) {
  let diferencia = fecha_actual - fecha_creacion_receta;
  let diferenciaDias = diferencia / (1000 * 60 * 60 * 24);
  diferenciaDias = Math.round(diferenciaDias);
  if (type_user == 'clue' && diferenciaDias >= 3) {
    return false;
  }
  return true;
}

async function addServicio(req, res) {
  console.log(req.body);
  const { fecha_prescripcion, fecha_surtimiento, folio, medicina, receta_comunitaria } = req.body
  const entidad_fed = [1, 4].includes(req.usdata.fk_id_cat_type_users) ?
    req.body.entidad_fed : req.usdata.fk_id_estado;
  const clues = [1, 2, 4].includes(req.usdata.fk_id_cat_type_users) ?
    req.body.clues : req.usdata.clue_relacionada_produccion;
  let response = { success: false, msg: '', data: [] }
  try {
    let medicamentos = Object.values(JSON.parse(medicina))

    if (medicamentos) {
      let cadena = ''
      let contador = 0

      for (item of medicamentos) {
        contador++
        if (!item.id || !item.cantidad_medicamento_recetado || !item.cantidad_medicamento_surtido) {
          cadena += `Todos los campos del servicio de la fila ${contador} son requeridos.<br>`
        }

        if (item.cantidad_medicamento_recetado <= 0 /*|| item.cantidad_medicamento_surtido <= 0*/) {
          cadena += `El valor debe ser mayor a 0, en los servicios, en la fila ${contador}.<br>`
        }
      }

   

      if (cadena) {
        response.msg = cadena
        return res.status(200).json(response)
      }
    }

    //Iniciamos transaccion
    await PGconn.query('BEGIN')

    nuevaRecetaProduccion = await produccionModel.create({
      entidad_fed: entidad_fed,
      clues: clues,
      fecha_preescripcion: fecha_prescripcion,
      fecha_surtimiento: fecha_surtimiento,

    })
    // validacion de si se creo la receta
    if (!nuevaRecetaProduccion) {
      response.msg = 'Error al crear el formulario de produccion'
      await PGconn.query('ROLLBACK')
      return res.status(200).json(response)
    }
    const idRecetaCreada = nuevaRecetaProduccion.id_produccion;
    if (medicamentos) {
      for (item of medicamentos) {
        await produccionDetalleServiciosModel.create({
          fk_id_produccion: idRecetaCreada,
          fk_id_servicio: item.id,
          cantidad_expedida: item.cantidad_medicamento_surtido,
          cantidad_receptida: item.cantidad_medicamento_recetado,
          estatus: true
        })
      }
    }
    await PGconn.query('COMMIT')
    response.success = true
    response.msg = '¡Correcto!'
    return res.status(200).json(response)
  } catch (error) {
    console.log(error)
    response.msg = 'Error al guardar registro'
    await PGconn.query('ROLLBACK')
    return res.status(500).json(response)
  }
}

async function getDataExcelProduccion(req, res) {
  const { date1, date2 } = req.body;
  const dateCondition = {};

  if (date1 > date2) {
    return res.status(400).json({ success: false, msg: 'La fecha de inicio no puede ser mayor a la fecha final' });
  }

  if (date1 && date2) {
    dateCondition.fecha_creacion = {
      [Op.between]: [new Date(date1), new Date(date2)]
    };
  }

  let formulario;
  let where = 'WHERE DATE(P.fecha_creacion) BETWEEN $1 AND $2 AND P.estatus = TRUE AND RDS.estatus = true';
  const bind = [new Date(date1 + 'T00:00:00.000'), new Date(date2 + 'T23:59:59.999')];

  if (req.usdata.fk_id_cat_type_users == 3) {
    // formulario = await recetas.findAll({
    //   where: {
    //     entidad_fed: String(req.usdata.fk_id_estado),
    //     clues: String(req.usdata.uname),
    //     ...dateCondition
    //   },
    // });
    where += ' AND entidad_fed = $3 AND clues=$4';
    bind.push(req.usdata.fk_id_estado);
    bind.push(req.usdata.uname);

  } else if (req.usdata.fk_id_cat_type_users == 2) {
    // formulario = await recetas.findAll({
    //   where: {
    //     entidad_fed: String(req.usdata.fk_id_estado),
    //     ...dateCondition
    //   },
    // });
    where += ' AND entidad_fed = $3';
    bind.push(req.usdata.fk_id_estado);

  } else if (req.usdata.fk_id_cat_type_users == 4 || req.usdata.fk_id_cat_type_users == 1) {
    // formulario = await recetas.findAll({
    //   where: {
    //     ...dateCondition
    //   },
    // });
  }
  formulario = await dbConection.query(
    `SELECT 
    P.id_produccion,
    CE.estado,
    P.clues,
    P.fecha_preescripcion,
    P.fecha_surtimiento,
    CS.id,
    CS.descripcion,
    CS.tipo,
    RDS.cantidad_receptida,
    RDS.cantidad_expedida
    FROM produccion P
    JOIN cat_estados CE ON P.entidad_fed = CE.id_estado
    JOIN recetas_detalle_servicios RDS ON P.id_produccion = RDS.fk_id_produccion
    JOIN cat_servicios CS ON RDS.fk_id_servicio = CS.id
        ` + where + ' ORDER BY P.id_produccion',
    {
      bind: bind, // Pasa los valores en orden
      type: dbConection.QueryTypes.SELECT,
    }
  );
  // console.log(formulario)
  if (formulario == null || formulario.length === 0) {
    console.log("No hay formulario con datos");
    return res.status(204).send(); // Sin contenido
  } else {
    try {
      const buffer = await generarXLSFormularioProduccion(formulario);
      res.setHeader('Content-Disposition', 'attachment; filename=formulario_excel.xlsx');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      return res.send(buffer);
    } catch (error) {
      console.error('Error al generar el archivo Excel:', error);
      return res.status(500).send('Error al generar el archivo Excel');
    }
  }
}

async function desactivarFormularioProduccion(req, res) {
  let id_formularioRecetas = req.body.id;

  try {
    //console.log('ID:', JSON.stringify(id));
    //const resultUpdate = FormularioModel.destroy({where:{ id_formulario: id }});
    const resultUpdate = await produccion.findOne({ where: { id_produccion: id_formularioRecetas } });
    console.log(resultUpdate)
    resultUpdate.estatus = false;
    await resultUpdate.save();

    // console.log(resultUpdate);
    // await  registroBitacoraControl(id_user,'Administrador',curp,3,'');
    if (!resultUpdate) return; //No deberian poderse intentar con curp de no usuarios.
    res.json({ success: true, msg: 'Registro Eliminado' });
  } catch (e) {
    // await  registroBitacoraControl(id_user,'Administrador','',500,'usuariosController.deActiveUser  ::' + error.message);
    console.error('--->>> usuariosController.deActiveUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}

module.exports = {
  formsProduccion,
  addServicio,
  obtenerFormulariosProduccion,
  obtenerRecetaProduccion,
  desactivarFormularioProduccion,
  editarRecetaProduccion,
  getDataExcelProduccion,
}

