// (() => {
//   // overrides URL methods to be able to retrieve the original blobs later on
//   const old_create = URL.createObjectURL;
//   const old_revoke = URL.revokeObjectURL;
//   Object.defineProperty(URL, "createObjectURL", {
//     get: () => storeAndCreate,
//   });
//   Object.defineProperty(URL, "revokeObjectURL", {
//     get: () => forgetAndRevoke,
//   });
//   Object.defineProperty(URL, "getFromObjectURL", {
//     get: () => getBlob,
//   });
//   const dict = {};

//   function storeAndCreate(blob) {
//     const url = old_create(blob); // let it throw if it has to
//     dict[url] = blob;
//     return url;
//   }

//   function forgetAndRevoke(url) {
//     old_revoke(url);
//     try {
//       if (new URL(url).protocol === "blob:") {
//         delete dict[url];
//       }
//     } catch (e) {}
//   }

//   function getBlob(url) {
//     return dict[url] || null;
//   }
// })();

// // para determinar si es mobile
// var isMobile = {
//   Android: function () {
//     return navigator.userAgent.match(/Android/i);
//   },
//   BlackBerry: function () {
//     return navigator.userAgent.match(/BlackBerry/i);
//   },
//   iOS: function () {
//     return navigator.userAgent.match(/iPhone|iPad|iPod/i);
//   },
//   Opera: function () {
//     return navigator.userAgent.match(/Opera Mini/i);
//   },
//   Windows: function () {
//     return navigator.userAgent.match(/IEMobile/i);
//   },
//   any: function () {
//     return (
//       isMobile.Android() ||
//       isMobile.BlackBerry() ||
//       isMobile.iOS() ||
//       isMobile.Opera() ||
//       isMobile.Windows()
//     );
//   },
// };

// var indexCam = 0;
// if (isMobile.any()) {
//   indexCam = 1;
// }
// if (isMobile.iOS()) {
//   indexCam = 1;
// }

// const videoElement = document.querySelector("video");

// const videoSelectIdent = document.querySelector("select#identSource");
// const videoSelectSelfie = document.querySelector("select#selfieSource");
// const videoSelectVideo = document.querySelector("select#vidSource");
// const selectors = [videoSelectIdent, videoSelectSelfie, videoSelectVideo];

// var localstreams = [];
// var event_vid = [false, false, false, false, false, false];

// function dophoto() {
//   // console.log('indexcam a '+indexCam);
//   $("#video").show();
//   $("#img").hide();

//   // Declaramos elementos del DOM
//   console.log("video");

//   var video = document.getElementById("video"),
//     canvas = document.getElementById("canvas"),
//     boton = document.getElementById("foto"),
//     estado = document.getElementById("estado");
//   //para habilitar dispositivos de video
//   navigator.mediaDevices
//     .enumerateDevices()
//     .then((devices) => {
//       estado.innerHTML = "Cargando cámara...";

//       var videoSource;

//       // Obtiene la camara seleccionada y la settea con su configuracion exact para iniciar la camara
//       if (type == "1" || type == "2") {
//         videoSource = videoSelectIdent.value;
//       }

//       if (type == "3") {
//         videoSource = videoSelectSelfie.value;
//       }

//       const constraints = {
//         video: { deviceId: videoSource ? { exact: videoSource } : undefined },
//       };
//       return navigator.mediaDevices.getUserMedia(constraints);
//     })
//     .then(function (Stream) {
//       localstreams.push(Stream);

//       estado.innerHTML = "De click sobre el video para tomar la fotografía";
//       //var video = document.querySelector('video');
//       video.srcObject = Stream;
//       video.onloadedmetadata = function (e) {
//         video.play();
//       };

//       if (!event_vid[type]) {
//         event_vid[type] = true;
//         video.addEventListener("click", function (e) {
//           e.preventDefault();
//           estado.innerHTML = "";
//           document.getElementById("cptd").value = "0";
//           estado.innerHTML = "De click sobre el video para tomar la fotografía";

//           if (video.paused) {
//             // console.log("Pausa");
//             video.play();
//           } else {
//             document.getElementById("cptd").value = "0";
//             estado.innerHTML = "Procesando imagen espere ...";
//             //Pausar reproducción
//             video.pause();
//             //Obtener contexto del canvas y dibujar sobre él
//             var contexto = canvas.getContext("2d");
//             canvas.width = video.videoWidth;
//             canvas.height = video.videoHeight;
//             contexto.drawImage(video, 0, 0, canvas.width, canvas.height);

//             // var foto = canvas.toDataURL(); //Esta es la foto, en base 64
//             document.getElementById("cptd").value = "1";
//             estado.innerHTML =
//               "Fotografía capturada con éxito, para volver a tomar la fotografía de click sobre la imagen";
//             // console.log("Reproduciendo");
//           }
//         });
//       }
//     })
//     .catch(function (err) {
//       console.log(err.name + ": " + err.message);
//     });
// }

// function dovideo(type) {
//   indexCam = 0;
//   console.log("indexcam b " + indexCam);
//   //
//   // alert('indexcam'+indexCam);

//   $("#video").show();
//   $("#img").hide();

//   // Declaramos elementos del DOM
//   var video = document.getElementById("video"),
//     videosr = document.getElementById("video5"),
//     canvas = document.getElementById("canvas"),
//     boton = document.getElementById("foto" + type),
//     grabar = document.getElementById("grabar"),
//     estado = document.getElementById("estado" + type);

//   //    var faceapi = opendir("models/");

//   //para habilitar dispositivos de video
//   Promise.all([faceapi.nets.tinyFaceDetector.loadFromUri("assets/js/models")]);
//   navigator.mediaDevices
//     .enumerateDevices()
//     .then((devices) => {
//       estado.innerHTML = "Cargando cámara...";
//       // console.log("Cargando cámara...");

//       const videoSource = videoSelectVideo.value;
//       const constraints = {
//         video: { deviceId: videoSource ? { exact: videoSource } : undefined },
//         audio: true,
//       };
//       return navigator.mediaDevices.getUserMedia(constraints);
//     })
//     .then(function (Stream) {
//       localstreams.push(Stream);

//       estado.innerHTML = "";
//       //var video = document.querySelector('video');
//       video.srcObject = Stream;
//       video.onloadedmetadata = function (e) {
//         video.play();
//       };

//       if (!event_vid[type]) {
//         event_vid[type] = true;

//         video.addEventListener("play", () => {
//           grabar.style.display = "none";
//           video.style.display = "block";
//           videosr.style.display = "none";
//           const canvas = faceapi.createCanvasFromMedia(video);
//           // $('#idvideopcv').width(video.width);
//           // $('#idvideopcv').height(video.height);

//           $("#idvideopcv").append(canvas);
//           const displaySize = { width: video.width, height: video.height };
//           faceapi.matchDimensions(canvas, displaySize);
//           var detect = 0;
//           estado.innerHTML =
//             "Detectando rostro, por favor colóca tu rostro hasta que el borde sea verde";
//           getline();
//           var inter = setInterval(async () => {
//             const detections = await faceapi.detectAllFaces(
//               video,
//               new faceapi.TinyFaceDetectorOptions()
//             );
//             var size = Object.keys(detections).length;
//             if (size === 1) {
//               detect++;
//               $("#idvideopcv canvas").css("border-color", "green");
//             } else {
//               detect--;
//               $("#idvideopcv canvas").css("border-color", "red");
//             }
//             if (detect >= 1) {
//               var leyenda = $("#textoleyenda").val();
//               // console.log('texto: '+leyenda)
//               $("#leyendavar").html(leyenda);
//             }
//             if (detect >= 3) {
//               // console.log('start recording 1');
//               clearInterval(inter);
//               startcounter(1, 3);
//               setTimeout(function () {
//                 ajusterec(estado, video.srcObject, video, videosr);
//               }, 3000);
//             }

//           }, 1000);

//           var dos = 0;

//         });
//         video.addEventListener("pause", () => {
//           grabar.style.display = "block";
//         });
//         videosr.addEventListener("play", () => {
//           video.pause();
//         });
//         grabar.addEventListener("click", () => {
//           video.play();
//           videosr.pause();
//         });
//       }
//     })
//     .catch(function (err) {
//       console.log(err.name + ": " + err.message);
//     });
// }

// function startcounter(tipo, count) {
//   if (tipo == 1) {
//     $("#counter").html("Comenzando grabación");
//   }
//   var counter = setInterval(async () => {
//     $("#counter").html(count--);
//     if (count === -1) {
//       clearInterval(counter);
//       $("#counter").html("");
//     }
//   }, 1000);
// }

// function getline() {
//   var leyenda = $("#textoleyenda").val();
//   if (leyenda === "") {
//     $.ajax({
//       url: "./datas/",
//       data: { liners: "weqeq" },
//       type: "POST",
//       dataType: "json",
//       beforeSend: function (objeto) {
//         $("#lockscreen").show();
//       },
//       success: function (data) {
//         $("#lockscreen").hide();
//         if (data.success) {
//           $("#textoleyenda").val(data.leyenda);
//         }
//       },
//       error: function (err) {
//         $("#lockscreen").hide();
//         $.confirm({
//           icon: "fa fa-spinner fa-spin",
//           title: "Aviso",
//           content: "Ocurrio un problemas al consultar la información.",
//           type: "red",
//           autoClose: "logoutUser|5000",
//           buttons: {
//             logoutUser: {
//               text: "cerrar",
//               btnClass: "btn-red",
//               action: function () {},
//             },
//           },
//         });
//       },
//     });
//   }
// }

// function ajusterec(estado, stream, video, videosr) {
//   var leyenda = $("#textoleyenda").val();
//   estado.innerHTML =
//     "Grabando durante 10 segundos <br> di la frase en la parte inferior" +
//     '<hr><i class="fas fa-record-vinyl fa-2x blink_me" aria-hidden="true" style="color: red;"></i><h5 style="color:white"> GRABANDO</h5>';
//   startRecording(stream, 11000).then((recordedChunks) => {
//     let recordedBlob = new Blob(recordedChunks, { type: "video/webm" });

//     const formblob = new FormData();
//     formblob.append("videosend", "1");
//     formblob.append("blob-video", recordedBlob, "videovot.webm");
//     var leyenda = $("#textoleyenda").val();
//     formblob.append("leyenda", leyenda);
//     //alert('size: '+recordedBlob.size);

//     $("#lockscreen").show();
//     console.log("size: " + recordedBlob.size);
//     var xhr = new XMLHttpRequest();
//     xhr.open("POST", "./datas/", true);
//     xhr.onload = function (e) {
//       console.log("Sent");
//       location.reload();
//     };
//     xhr.send(formblob);

//     document.getElementById("cptd4_saved").value = "1";

//     video.pause();
//     videosr.style.display = "block";
//     video.style.display = "none";
//     $("#idvideopcv canvas").remove();

//     //location.reload();

//     // var reader = new FileReader();
//     // reader.readAsDataURL(recordedBlob);
//     // reader.onloadend = function() {
//     //     var base64data = reader.result;
//     //     //console.log(base64data);
//     //     videosr.src = base64data;
//     // }

//     //videosr.src = URL.createObjectURL(recordedBlob);
//     // console.log(recordedBlob);
//     grabar.style.display = "block";
//     estado.innerHTML = "Terminó la grabación, revisa tu video";

//     // var file2=dataURLtoFile(videosr.src,'videorec.webm');
//     // $('#videofile4').val(file2);
//     // $('#video3').show();
//     // console.log(recording.src);
//   });
// }

// function okcanva(obj, type) {
//   function draw() {
//     obj.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
//     if (obj.getContext) {
//       var ctx = obj.getContext("2d");
//       ctx.beginPath();
//       ctx.arc(75, 75, 50, 0, Math.PI * 2, true); // Outer circle
//       ctx.stroke();
//     }
//   }
// }

// function wait(delayInMS) {
//   return new Promise((resolve) => setTimeout(resolve, delayInMS));
// }

// function startRecording(stream, lengthInMS) {
//   let recorder = new MediaRecorder(stream);
//   let data = [];

//   recorder.ondataavailable = (event) => data.push(event.data);
//   startcounter(2, 10);
//   recorder.start();

//   let stopped = new Promise((resolve, reject) => {
//     recorder.onstop = resolve;
//     recorder.onerror = (event) => reject(event.name);
//   });

//   let recorded = wait(lengthInMS).then(
//     () => recorder.state === "recording" && recorder.stop()
//   );

//   return Promise.all([stopped, recorded]).then(() => data);
// }

// function dataURLtoFile(dataurl, filename) {
//   var arr = dataurl.split(","),
//     mime = arr[0].match(/:(.*?);/)[1],
//     bstr = atob(arr[1]),
//     n = bstr.length,
//     u8arr = new Uint8Array(n);

//   while (n--) {
//     u8arr[n] = bstr.charCodeAt(n);
//   }

//   return new File([u8arr], filename, { type: mime });
// }

// // Agregar evento onchange al momento de seleccionar la nueva camara para resetear los streams activos
// // videoSelectIdent.onchange = changeCamera;

// function changeCamera(type) {
//   switch (type) {
//     case 1:
//       // $("#canvas1").css("display","none");
//       // $("#video1").css("display","none");
//       // $("#img1").show();

//       video1 = document.getElementById("video1");
//       video2 = document.getElementById("video2");

//       // $("#canvas2").css("display","none");
//       // $("#video2").css("display","none");
//       // $("#img2").show();

//       video1.pause();
//       video2.pause();

//       document.getElementById("cptd1").value = "1";
//       document.getElementById("cptd2").value = "1";
//       break;
//     case 2:
//       video3 = document.getElementById("video3");

//       // $("#canvas3").css("display","none");
//       // $("#video3").css("display","none");
//       // $("#img3").show();

//       video3.pause();

//       document.getElementById("cptd3").value = "1";

//       break;
//     case 3:
//       video4 = document.getElementById("video4");

//       $("#canvas4").css("display", "none");
//       $("#video4").css("display", "none");
//       $("#img4").show();

//       video4.pause();

//       document.getElementById("cptd4").value = "1";
//       break;
//   }
//   // Arreglo de camaras activas. detiene cada una y apaga la camara
//   localstreams.forEach((element) =>
//     element.getTracks().forEach((track) => track.stop())
//   );
//   localstreams = [];

//   if (type == 1) {
//     dophoto(1);
//     dophoto(2);
//   } else if (type == 2) {
//     dophoto(3);
//   }
// }

// // Enlista las camaras disponibles en un selector
// function listDevices() {
//   navigator.mediaDevices
//     .enumerateDevices()
//     .then((devices) => {
//       // en cuanto vea los devices revisa si ya hay video para el listener de play pause
//       var grabar = document.getElementById("grabar");
//       grabar.addEventListener("click", () => {
//         if ($("#grabar").data("graba") == 2) {
//           dovideo(4);
//         }
//       });

//       const values = selectors.map((select) => select.value);
//       selectors.forEach((select) => {
//         while (select.firstChild) {
//           select.removeChild(select.firstChild);
//         }
//       });

//       for (let i = 0; i !== devices.length; ++i) {
//         const deviceInfo = devices[i];
//         // console.log(deviceInfo);

//         const option_ident = document.createElement("option");
//         option_ident.value = deviceInfo.deviceId;

//         const option_selfie = document.createElement("option");
//         option_selfie.value = deviceInfo.deviceId;

//         const option_video = document.createElement("option");
//         option_video.value = deviceInfo.deviceId;

//         if (deviceInfo.kind === "videoinput") {
//           option_ident.text =
//             deviceInfo.label || `camera ${videoSelectIdent.length + 1}`;
//           option_selfie.text =
//             deviceInfo.label || `camera ${videoSelectSelfie.length + 1}`;
//           option_video.text =
//             deviceInfo.label || `camera ${videoSelectVideo.length + 1}`;

//           videoSelectIdent.appendChild(option_ident);
//           videoSelectSelfie.appendChild(option_selfie);
//           videoSelectVideo.appendChild(option_video);
//         }
//       }
//       selectors.forEach((select, selectorIndex) => {
//         if (
//           Array.prototype.slice
//             .call(select.childNodes)
//             .some((n) => n.value === values[selectorIndex])
//         ) {
//           select.value = values[selectorIndex];
//         }
//       });
//     })
//     .catch(function (err) {
//       console.log("Error " + err);
//     });
// }

// function closeCameras() {
//   if (localstreams.length > 0) {
//     localstreams.forEach((element) =>
//       element.getTracks().forEach((track) => track.stop())
//     );
//     localstreams = [];
//   }
// }

// listDevices();


