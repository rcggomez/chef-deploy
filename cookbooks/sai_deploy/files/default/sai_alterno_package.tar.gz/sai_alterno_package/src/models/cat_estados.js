const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const cat_estados = dbConection.define('cat_estados',
    {
        id_estado:{
            type:  DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement:true
        },
        estado:{
            type: DataTypes.STRING
        },
        edo_nom_lg:{
            type: DataTypes.STRING
        },
        cve_edo:{
            type: DataTypes.STRING
        },
        abbrev:{
            type: DataTypes.STRING
        },
        literal_edov:{
            type: DataTypes.STRING
        },
    },
    {
        createdAt: false,
        updatedAt: false
    }
);

module.exports = cat_estados;