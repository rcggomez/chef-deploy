const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const filesModel = dbConection.define('files',
    {
        id_file: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        file_name: {
            type: DataTypes.STRING,
        },
        file_type: {
            type: DataTypes.STRING,
        },
        file_size: {
            type: DataTypes.INTEGER,
        },
        file_path: {
            type: DataTypes.STRING,
        },
        file_date:{
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        },
        fk_id_storage: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'storage_files',
                key: 'id_storage',
            },
            onDelete: 'RESTRICT',
        },
    },
    {
        createdAt: false,
        updatedAt: false
    }
);
// filesModel.sync()
// filesModel.sync({ force: true })
module.exports = filesModel;