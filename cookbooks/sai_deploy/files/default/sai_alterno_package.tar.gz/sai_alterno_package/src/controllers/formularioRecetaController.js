const sequelizeConfig = require("../config/postgressdb");
const dbConection = require('../config/postgressdb');
const userModel = require("../models/users");
const getNombreEntidad = require('../util/diccionario');
const { generarXLSFormulario } = require("../util/generarExcel");
const cat_estados = require("../models/cat_estados");
const CatalogModel = require("../models/CatalogModel");
const catMedicamentos = require("../models/cat_medicamentos");
const FormularioModel = require("../models/FormularioModel");
const bcrypt = require("bcrypt");
const fs = require("fs");
const path = require("path");
const { renapoConsultarCurp } = require("../util/WebServices");
const { genCode, completarCedulaProfesional } = require("../util/util");
const { enviarEmail } = require("../util/util");
const PGconn = require("../config/postgressdb");
const { stringify } = require("querystring");
const { Op } = require('sequelize'); // Asegúrate que esto esté al principio de tu archivoconst sequelizeConfig = require("../config/postgressdb");
const cat_clues = require("../models/cat_clues");
const cat_medicamentos = require("../models/cat_medicamentos");
const recetas = require("../models/recetas");
const recetasDetalleMedicamento = require("../models/recetasDetalleMedicamento");
const { generarXLSFormularioRecetas } = require("../util/generarExcel");
const bitacora = require("../models/bitacora");
const { Parser } = require('json2csv');

async function formsRecetas(req, res) {
  let usuarios = await userModel.findAll();
  let estados = global.catalogos.cat_entidad_federativa;
  let formulario = []
  // await FormularioModel.findAll({
  //   where: { estatus: true },
  // });
  let clue = "";

  if (req.usdata.fk_id_cat_type_users == 3) { // Filtracion de mostrar todo de la misma clue

    // formulario = await FormularioModel.findAll({
    //   where: { entidad_fed: String(req.usdata.fk_id_estado), clues: String(req.usdata.uname),estatus: true },

    // });

    estados = await cat_estados.findAll({ where: { id_estado: req.usdata.fk_id_estado } });
    clue = await userModel.findAll({ where: { uname: req.usdata.uname, fk_id_cat_type_users: String('3') } });
  } else if (req.usdata.fk_id_cat_type_users == 2) { // filtracion de mostrar visor estatal
    // formulario = await FormularioModel.findAll({
    //   where: { entidad_fed: String(req.usdata.fk_id_estado),estatus: true  },

    // });
    estados = await cat_estados.findAll({ where: { id_estado: req.usdata.fk_id_estado } });
    clue = await userModel.findAll({ where: { fk_id_cat_type_users: String('3'), fk_id_estado: String(req.usdata.fk_id_estado) } });

  }
  else if (req.usdata.fk_id_cat_type_users == 4 || req.usdata.fk_id_cat_type_users == 1) { // filtracion de mostrar visor general y 
    // formulario = await FormularioModel.findAll({
    //   where: { estatus: true },
    // });
    estados = global.catalogos.cat_entidad_federativa;
    clue = await userModel.findAll({ where: { fk_id_cat_type_users: String('3') } });
  }

  const formularioMapped = formulario.map(item => {
    return {
      ...item.dataValues,
      entidad_fed: getNombreEntidad(item.entidad_fed)
    };
  });
  // } else {
  // formulario = await FormularioModel.findAll();

  let buffer;
  if (formulario == null) {
    buffer = "";
    console.log("No hay formulario con datos");
    formulario = [];
  } else {
    // console.log(formulario);
    buffer = await generarXLSFormulario(formulario);

  }

  let medicamentos = await cat_medicamentos.findAll();
  // buffer: buffer.toString("base64"),


  // console.log(formulario);
  try {

    res.render("formularioRecetas", {
      ...req.usdata,
      formulario: formularioMapped,
      cat_type_users: global.catalogos.cat_type_users,
      cat_entidades_admins: estados, //global.catalogos.cat_entidades_admins,
      sub_modulos: global.catalogos.sub_modulo, //sub_modulos,
      listaUsuarios: usuarios,
      directorio_activo: process.env.ACTIVE_DIRECTORY,
      buffer: buffer.toString("base64"),
      clues: clue,
      medicamentos: medicamentos
    });
  } catch (error) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.adduser  ::' + error.message);
    console.error("--->>> usuariosController.formsRecetas ");
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: "Error" });
  }
}

async function obtenerFormulariosRecetas(req, res) {
  const { draw, start, length } = req.body;
  const searchValue = req.body.search.value;

  // Convertir a números enteros para que Sequelize los use correctamente
  const offsetValue = parseInt(start, 10);
  const limitValue = parseInt(length, 10);

  const where = { estatus: true }; // Condición base de estatus

  // Lógica para aplicar condiciones de usuario (fk_id_cat_type_users)
  if (req.usdata.fk_id_cat_type_users == 3) {
    where.entidad_fed = String(req.usdata.fk_id_estado);
    where.clues = String(req.usdata.uname); // Asumo que aquí no necesitas Op.or como en el otro caso
  } else if (req.usdata.fk_id_cat_type_users == 2) {
    where.entidad_fed = String(req.usdata.fk_id_estado);
  }

  // Aplicar la búsqueda global (searchValue) si existe
  if (searchValue) {
    where[Op.or] = [
      // Asegúrate que estos nombres de columnas existan en tu tabla 'recetas'
      { clues: { [Op.like]: `%${searchValue}%` } }, // Ejemplo de otra columna
      { folio: { [Op.like]: `%${searchValue}%` } },     // Ejemplo de otra columna
      // Añade aquí todas las columnas por las que quieras buscar en las recetas
    ];
  }

  try {
    // Primero, obtener el conteo total de registros sin la búsqueda global
    // Esto es para 'recordsTotal' en DataTables
    const totalCountWhere = { estatus: true };
    if (req.usdata.fk_id_cat_type_users == 3) {
      totalCountWhere.entidad_fed = String(req.usdata.fk_id_estado);
      totalCountWhere.clues = String(req.usdata.uname);
    } else if (req.usdata.fk_id_cat_type_users == 2) {
      totalCountWhere.entidad_fed = String(req.usdata.fk_id_estado);
    }
    const totalCount = await recetas.count({ where: totalCountWhere });

    // Luego, obtener los registros paginados y filtrados
    // 'count' aquí será el 'recordsFiltered'
    const { count: filteredCount, rows: paginatedFormulariosRecetas } = await recetas.findAndCountAll({
      where: where, // Se aplican todas las condiciones aquí, incluyendo searchValue y las de usuario
      order: [['id_receta', 'ASC']], // Tu ordenamiento predeterminado
      offset: offsetValue,            // El inicio de la página
      limit: limitValue,              // El número de registros por página
    });

    // Mapear y transformar los datos (si es necesario)
    const dataFormatted = paginatedFormulariosRecetas.map(item => ({
      ...item.dataValues,
      entidad_fed: getNombreEntidad(item.entidad_fed) // Asegúrate que getNombreEntidad esté disponible
    }));

    const respuesta = {
      draw: draw,
      recordsTotal: totalCount,      // Conteo total sin búsqueda global
      recordsFiltered: filteredCount, // Conteo después de aplicar filtros y búsqueda
      data: dataFormatted             // Los registros de la página actual
    };

    res.json(respuesta);
  } catch (error) {
    // Manejo de errores para depuración
    console.error('Error en obtenerFormulariosRecetas:', error.message);
    console.error('Stack Trace:', error.stack);
    res.status(500).json({ error: 'Error interno del servidor al obtener formularios de recetas.' });
  }
}

async function obtenerReceta(req, res) {
  try {
    let response = { success: false, msg: '', data: [] };
    const { id_receta } = req.body;
    const receta = await recetas.findOne({
      where: { id_receta: id_receta }
    });
    const medicamentos = await recetasDetalleMedicamento.findAll({
      where: { fk_id_receta: id_receta, estatus: true }
    });
    const destallesMedicamentos = await catMedicamentos.findAll();
    const medicamentosMapped = medicamentos.map(item => {
      const medicamento = destallesMedicamentos.find(med => med.clave_sector_salud === item.fk_id_medicamento);
      return {
        ...item.dataValues, // Incluye todas las propiedades de recetasDetalleMedicamento (incluyendo cantidad_faccionado)
        descripcion: medicamento.descripcion,
        presentacion: medicamento.presentacion
      };
    });
    response.success = true;
    response.data = { receta, medicamentos: medicamentosMapped };
    res.json(response);
  } catch (error) {
    console.error("--->>> usuariosController.obtenerReceta ");
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: "Error al obtener la receta" });
  }
}

async function editarReceta(req, res) {
  let bitacoraEstatus = 2;
  let bitacoraRegistroAnteriorRecetas = await recetas.findByPk(parseInt(req.body.id_receta));
  let bitacoraRegistroAnteriorRecetasDetalladas = await recetasDetalleMedicamento.findOne({ where: { fk_id_receta: req.body.id_receta }, raw: true });
  let bitacoraRegistroAnterior = { ...bitacoraRegistroAnteriorRecetas.dataValues, ...bitacoraRegistroAnteriorRecetasDetalladas };
  console.log(bitacoraRegistroAnterior);
  const { id_receta, entidad_fed, clues, fecha_prescripcion, fecha_surtimiento, folio, medicina, receta_comunitaria } = req.body
  let response = { success: false, msg: '', data: [] }
  try {
    let receta = await recetas.findOne({
      where: { id_receta: id_receta }
    });

    let fecha_creacion_receta = new Date(receta.fecha_creacion);
    fecha_creacion_receta.setHours(fecha_creacion_receta.getHours() - 6);
    let fecha_actual = new Date();
    let type_user = req.usdata.type_user;
    if (!verificacionEditableFechas(fecha_creacion_receta, fecha_actual, type_user)) {
      response.msg = 'No se puede editar la receta, han pasado más de 3 días desde su creación.'
      return res.status(200).json(response)
    }
    if (!receta) {
      response.msg = 'No se encontró la receta'
      return res.status(404).json(response)
    }
    let medicamentos = Object.values(JSON.parse(medicina))
    if (medicamentos) {
      let cadena = ''
      let contador = 0
      for (item of medicamentos) {
        contador++
        if (!item.fk_clave_sector_salud || !item.cantidad_medicamento_recetado || !item.cantidad_medicamento_surtido) {
          cadena += `Todos los campos de medicamentos suministrados de la fila ${contador} son requeridos.<br>`
        }

        if (item.cantidad_medicamento_recetado <= 0 /*|| item.cantidad_medicamento_surtido <= 0*/) {
          cadena += `El valor debe ser mayor a 0, en medicamentos, en la fila ${contador}.<br>`
        }
      }

      const vistos = new Set();
      const duplicados = medicamentos.filter((objeto, item) => {
        if (objeto.fk_clave_sector_salud.trim()) {
          const clave = objeto.fk_clave_sector_salud;
          if (vistos.has(clave)) {
            cadena += `El medicamento de la fila ${item + 1} ya existe, favor de seleccionar otra opcion.<br>`
          }
          vistos.add(clave);
          return false;
        }
      });

      if (cadena) {
        response.msg = cadena
        return res.status(200).json(response)
      }
    }

    await sequelizeConfig.query('BEGIN')

    //eliminar los medicamentos de la receta
    let detallesMedicamentos = await recetasDetalleMedicamento.findAll({
      where: { fk_id_receta: id_receta }
    });

    for (detalle of detallesMedicamentos) {
      detalle.estatus = false
      await detalle.save()
    }

    if (medicamentos) {
      for (item of medicamentos) {
        await recetasDetalleMedicamento.create({
          fk_id_receta: receta.id_receta,
          fk_id_medicamento: item.fk_clave_sector_salud,
          cantidad_expedida: item.cantidad_medicamento_surtido,
          cantidad_receptida: item.cantidad_medicamento_recetado,
          fraccionado: item.cantidad_faccionado,
          estatus: true
        })
      }
    }

    receta.entidad_fed = entidad_fed
    receta.clues = clues
    receta.fecha_preescripcion = fecha_prescripcion
    receta.fecha_surtimiento = fecha_surtimiento
    receta.folio = folio
    receta.receta_comunitaria = receta_comunitaria
    await receta.save()
    // console.log(receta);
    await sequelizeConfig.query('COMMIT')
    let bitacoraRegistroActualrRecetas = await recetas.findByPk(parseInt(req.body.id_receta));
    let bitacoraRegistroActualrRecetasDetalladas = await recetasDetalleMedicamento.findOne({ where: { fk_id_receta: req.body.id_receta }, raw: true });
    let bitacoraRegistroActual = { ...bitacoraRegistroActualrRecetas.dataValues, ...bitacoraRegistroActualrRecetasDetalladas };
    console.log(bitacoraRegistroActual);
    let bitacoraCreate = await bitacora.create({
      fk_id_responsable: req.usdata.id_user,
      fk_id_registro_modificado: id_receta,
      registro_antes: JSON.stringify(bitacoraRegistroAnterior),
      registro_despues: JSON.stringify(bitacoraRegistroActual),
      fk_id_estatus: bitacoraEstatus
    });

    await recetas.increment('numero_cambios', { by: 1, where: { id_receta: id_receta } });
    response.success = true
    response.msg = 'La receta se actualizó correctamente.'
    return res.status(200).json(response)
  } catch (error) {
    console.log(error)
    response.msg = 'Error al guardar registro'
    await sequelizeConfig.query('ROLLBACK')
    return res.status(500).json(response)
  }
}

function verificacionEditableFechas(fecha_creacion_receta, fecha_actual, type_user) {
  let diferencia = fecha_actual - fecha_creacion_receta;
  let diferenciaDias = diferencia / (1000 * 60 * 60 * 24);
  diferenciaDias = Math.round(diferenciaDias);
  if (type_user == 'clue' && diferenciaDias >= 3) {
    return false;
  }
  return true;
}

async function addReceta(req, res) {
  const { fecha_prescripcion, fecha_surtimiento, folio, medicina, receta_comunitaria } = req.body
  const entidad_fed = [1, 4].includes(req.usdata.fk_id_cat_type_users) ?
    req.body.entidad_fed : req.usdata.fk_id_estado;
  const clues = [1, 2, 4].includes(req.usdata.fk_id_cat_type_users) ?
    req.body.clues : req.usdata.uname;
  let response = { success: false, msg: '', data: [] }
  try {
    let medicamentos = Object.values(JSON.parse(medicina))

    if (medicamentos) {
      let cadena = ''
      let contador = 0

      for (item of medicamentos) {
        contador++
        if (!item.fk_clave_sector_salud || !item.cantidad_medicamento_recetado || !item.cantidad_medicamento_surtido) {
          cadena += `Todos los campos de medicamentos suministrados de la fila ${contador} son requeridos.<br>`
        }

        if (item.cantidad_medicamento_recetado <= 0 /*|| item.cantidad_medicamento_surtido <= 0*/) {
          cadena += `El valor debe ser mayor a 0, en medicamentos, en la fila ${contador}.<br>`
        }
      }

      /*             const vistos = new Set();
                  const duplicados = medicamentos.filter((objeto, item) => {
                      if(objeto.fk_clave_sector_salud.trim()){
                          const clave = objeto.fk_clave_sector_salud;
                          if (vistos.has(clave)) {
                              cadena += `El medicamento de la fila ${item + 1} ya existe, favor de seleccionar otra opcion.<br>`
                          }
                          vistos.add(clave);
                          return false;
                      }
                  }); */

      if (cadena) {
        response.msg = cadena
        return res.status(200).json(response)
      }
    }

    //Iniciamos transaccion
    await PGconn.query('BEGIN')

    nuevaReceta = await recetas.create({
      entidad_fed: entidad_fed,
      clues: clues,
      fecha_preescripcion: fecha_prescripcion,
      fecha_surtimiento: fecha_surtimiento,
      folio: folio,
      receta_comunitaria: receta_comunitaria,

    })
    const idRecetaCreada = nuevaReceta.id_receta;
    if (medicamentos) {
      for (item of medicamentos) {
        await recetasDetalleMedicamento.create({
          fk_id_receta: idRecetaCreada,
          fk_id_medicamento: item.fk_clave_sector_salud,
          cantidad_expedida: item.cantidad_medicamento_surtido,
          cantidad_receptida: item.cantidad_medicamento_recetado,
          fraccionado: item.cantidad_faccionado,
          estatus: true
        })
      }
    }
    await PGconn.query('COMMIT')
    response.success = true
    response.msg = '¡Correcto!'
    return res.status(200).json(response)
  } catch (error) {
    console.log(error)
    response.msg = 'Error al guardar registro'
    await PGconn.query('ROLLBACK')
    return res.status(500).json(response)
  }
}

async function getDataExcel(req, res) {
  const { date1, date2 } = req.body;
  const dateCondition = {};

  if (date1 > date2) {
    return res.status(400).json({ success: false, msg: 'La fecha de inicio no puede ser mayor a la fecha final' });
  }

  if (date1 && date2) {
    dateCondition.fecha_creacion = {
      [Op.between]: [new Date(date1), new Date(date2)]
    };
  }

  let formulario;
  let where = 'WHERE DATE(R.fecha_creacion) BETWEEN $1 AND $2 AND R.estatus = TRUE';
  const bind = [new Date(date1 + 'T00:00:00.000'), new Date(date2 + 'T23:59:59.999')];

  if (req.usdata.fk_id_cat_type_users == 3) {
    // formulario = await recetas.findAll({
    //   where: {
    //     entidad_fed: String(req.usdata.fk_id_estado),
    //     clues: String(req.usdata.uname),
    //     ...dateCondition
    //   },
    // });
    where += ' AND entidad_fed = $3 AND clues=$4';
    bind.push(req.usdata.fk_id_estado);
    bind.push(req.usdata.uname);

  } else if (req.usdata.fk_id_cat_type_users == 2) {
    // formulario = await recetas.findAll({
    //   where: {
    //     entidad_fed: String(req.usdata.fk_id_estado),
    //     ...dateCondition
    //   },
    // });
    where += ' AND entidad_fed = $3';
    bind.push(req.usdata.fk_id_estado);

  } else if (req.usdata.fk_id_cat_type_users == 4 || req.usdata.fk_id_cat_type_users == 1) {
    // formulario = await recetas.findAll({
    //   where: {
    //     ...dateCondition
    //   },
    // });
  }
  formulario = await dbConection.query(
    `SELECT 
        R.id_receta,
        CE.estado,
        R.clues,
        R.fecha_preescripcion,
        R.fecha_surtimiento,
        R.folio,
        CASE WHEN R.receta_comunitaria THEN 'SÍ' ELSE 'NO' END receta_comunitaria,
        CM.clave_sector_salud,
        CM.descripcion,
        CM.presentacion,
        rdm.cantidad_receptida,
        rdm.cantidad_expedida
        FROM recetas R
        JOIN cat_estados CE ON R.entidad_fed = CE.id_estado
        JOIN recetas_detalle_medicamento RDM ON R.id_receta = RDM.fk_id_receta
        JOIN cat_medicamentos CM ON RDM.fk_id_medicamento = CM.clave_sector_salud
        ` + where + ' ORDER BY R.id_receta',
    {
      bind: bind, // Pasa los valores en orden
      type: dbConection.QueryTypes.SELECT,
    }
  );
  // console.log(formulario)
  if (formulario == null || formulario.length === 0) {
    console.log("No hay formulario con datos");
    return res.status(204).send(); // Sin contenido
  } else {
    try {
      const buffer = await generarXLSFormularioRecetas(formulario);
      res.setHeader('Content-Disposition', 'attachment; filename=formulario_excel.xlsx');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      return res.send(buffer);
    } catch (error) {
      console.error('Error al generar el archivo Excel:', error);
      return res.status(500).send('Error al generar el archivo Excel');
    }
  }
}

async function getDataCSV(req, res) {
  const { date1, date2 } = req.body;
  const dateCondition = {};

  if (date1 > date2) {
    return res.status(400).json({ success: false, msg: 'La fecha de inicio no puede ser mayor a la fecha final' });
  }

  if (date1 && date2) {
    dateCondition.fecha_creacion = {
      [Op.between]: [new Date(date1), new Date(date2)]
    };
  }

  let formulario;
  let where = 'WHERE DATE(R.fecha_creacion) BETWEEN $1 AND $2 AND R.estatus = TRUE';
  const bind = [new Date(date1 + 'T00:00:00.000'), new Date(date2 + 'T23:59:59.999')];

  if (req.usdata.fk_id_cat_type_users == 3) {
    // formulario = await recetas.findAll({
    //   where: {
    //     entidad_fed: String(req.usdata.fk_id_estado),
    //     clues: String(req.usdata.uname),
    //     ...dateCondition
    //   },
    // });
    where += ' AND entidad_fed = $3 AND clues=$4';
    bind.push(req.usdata.fk_id_estado);
    bind.push(req.usdata.uname);

  } else if (req.usdata.fk_id_cat_type_users == 2) {
    // formulario = await recetas.findAll({
    //   where: {
    //     entidad_fed: String(req.usdata.fk_id_estado),
    //     ...dateCondition
    //   },
    // });
    where += ' AND entidad_fed = $3';
    bind.push(req.usdata.fk_id_estado);

  } else if (req.usdata.fk_id_cat_type_users == 4 || req.usdata.fk_id_cat_type_users == 1) {
    // formulario = await recetas.findAll({
    //   where: {
    //     ...dateCondition
    //   },
    // });
  }
  formulario = await dbConection.query(
    `SELECT 
        R.id_receta,
        CE.estado,
        R.clues,
        R.fecha_preescripcion,
        R.fecha_surtimiento,
        R.folio,
        CASE WHEN R.receta_comunitaria THEN 'SÍ' ELSE 'NO' END receta_comunitaria,
        CM.clave_sector_salud,
        CM.descripcion,
        CM.presentacion,
        rdm.cantidad_receptida,
        rdm.cantidad_expedida
        FROM recetas R
        JOIN cat_estados CE ON R.entidad_fed = CE.id_estado
        JOIN recetas_detalle_medicamento RDM ON R.id_receta = RDM.fk_id_receta
        JOIN cat_medicamentos CM ON RDM.fk_id_medicamento = CM.clave_sector_salud
        ` + where + ' ORDER BY R.id_receta',
    {
      bind: bind, // Pasa los valores en orden
      type: dbConection.QueryTypes.SELECT,
    }
  );
  // console.log(formulario)
  if (formulario == null || formulario.length === 0){
    console.log("No hay formulario con datos");
    return res.status(204).send(); // Sin contenido
  }

  try {
        const fields = [
          { label: 'ID', value: 'id_receta' },
          { label: 'Entidad Federativa', value: 'estado' },
          { label: 'CLUES', value: 'clues' },
          { label: 'Folio', value: 'folio' },
          { label: 'Receta Comunitaria', value: 'receta_comunitaria' },
          { label: 'Fecha Preescripción', value: 'fecha_preescripcion' },
          { label: 'Fecha Surtimiento', value: 'fecha_surtimiento' },
          { label: 'Clave Sector Salud', value: 'clave_sector_salud' },
          { label: 'Descripción', value: 'descripcion' },
          { label: 'Presentación', value: 'presentacion' },
          { label: 'Cantidad Recetada', value: 'cantidad_receptida' },
          { label: 'Cantidad Expedida', value: 'cantidad_expedida' }
        ];
        
        const opts = { fields, withBOM: true };

        const json2csvParser = new Parser(opts);
        const csv = json2csvParser.parse(formulario);

        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename=formulario_recetas.csv');
        
        return res.send(csv);

    } catch (error) {
        console.error('Error al generar el archivo CSV:', error);
        return res.status(500).send('Error al generar el archivo CSV');
    }

}

async function desactivarFormularioRecetas(req, res) {
  let id_formularioRecetas = req.body.id;

  try {
    //console.log('ID:', JSON.stringify(id));
    //const resultUpdate = FormularioModel.destroy({where:{ id_formulario: id }});
    const resultUpdate = await recetas.findOne({ where: { id_receta: id_formularioRecetas } });
    console.log(resultUpdate)
    resultUpdate.estatus = false;
    await resultUpdate.save();

    // console.log(resultUpdate);
    // await  registroBitacoraControl(id_user,'Administrador',curp,3,'');
    if (!resultUpdate) return; //No deberian poderse intentar con curp de no usuarios.
    res.json({ success: true, msg: 'Registro Eliminado' });
  } catch (e) {
    // await  registroBitacoraControl(id_user,'Administrador','',500,'usuariosController.deActiveUser  ::' + error.message);
    console.error('--->>> usuariosController.deActiveUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}

module.exports = {
  formsRecetas,
  obtenerFormulariosRecetas,
  addReceta,
  getDataExcel,
  getDataCSV,
  desactivarFormularioRecetas,
  obtenerReceta,
  editarReceta,
}

