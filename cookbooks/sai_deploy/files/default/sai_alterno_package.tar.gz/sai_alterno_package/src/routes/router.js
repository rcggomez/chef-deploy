const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const authController = require('../controllers/authController');
const dashController  = require('../controllers/dashController');
const usuariosController  = require('../controllers/usuariosController');
const formularioController  = require('../controllers/formularioController');
const formularioRecetaController  = require('../controllers/formularioRecetaController');
const formularioProduccionController  = require('../controllers/formularioProduccionController');
const medicamentosController  = require('../controllers/medicamentosController');
// const formularioMedicamentoController  = require('../controllers/formularioMedicamentoController');
const multer = require('multer');
const upload = multer();

router.get('/', dashController.inicio);
/**Rutas Modulo Usuarios */
router.get('/users', auth.isAuthenticated, usuariosController.users);
router.post('/obtenerUsers', auth.isAuthenticated, usuariosController.obtenerUsers);
router.post('/NuevoUsuario', auth.isAuthenticated, usuariosController.adduser);
router.post('/NuevoUsuarioValidarCurp', auth.isAuthenticated, usuariosController.NuevoUsuarioValidarCurp);
router.post('/obtenerPermisosUser', auth.isAuthenticated, usuariosController.obtenerPermisosUser);
router.post('/editarPermisosUser', auth.isAuthenticated, usuariosController.editarPermisosUser);
router.post('/desactivarUser', auth.isAuthenticated, usuariosController.deActiveUser);
router.post('/reactivarUser', auth.isAuthenticated, usuariosController.reActiveUser);
router.post('/actualizarContrasenaUser', auth.isAuthenticated, usuariosController.actualizarContrasenaUser);

router.get('/formulario', auth.isAuthenticated, formularioController.forms);
router.post('/obtenerFormularios', auth.isAuthenticated, formularioController.obtenerFormularios);
router.post('/formularioFiltro', auth.isAuthenticated, formularioController.getDataExcel);
router.post('/nuevoFormulario', auth.isAuthenticated, formularioController.addFormularioClue);
router.post('/obtenerDataFormulario', auth.isAuthenticated, formularioController.obtenerDataFormulario);
router.post('/editarFormulario', auth.isAuthenticated, formularioController.editarPermisosFormulario);
router.post('/desactivarFormulario', auth.isAuthenticated, formularioController.desactivarFormulario);

router.get('/formularioRecetas', [auth.isAuthenticated, auth.moduloRecetasHabilitado], formularioRecetaController.formsRecetas);
// router.get('/formularioMedicamentos', [auth.isAuthenticated, auth.moduloMedicamentosHabilitado], formularioMedicamentoController.formsMedicamentos);
router.post('/obtenerFormulariosRecetas', auth.isAuthenticated, formularioRecetaController.obtenerFormulariosRecetas);
// router.post('/obtenerFormulariosMedicamentos', auth.isAuthenticated, formularioMedicamentoController.obtenerFormulariosMedicamentos);
router.post('/obtenerReceta', auth.isAuthenticated, formularioRecetaController.obtenerReceta);
router.post('/editarReceta', auth.isAuthenticated, formularioRecetaController.editarReceta);
router.post('/nuevoFormularioRecetas', auth.isAuthenticated, formularioRecetaController.addReceta);
router.post('/formularioRecetasExcel', auth.isAuthenticated, formularioRecetaController.getDataExcel);
router.post('/formularioRecetasCSV', auth.isAuthenticated, formularioRecetaController.getDataCSV);
router.post('/desactivarFormularioRecetas', auth.isAuthenticated, formularioRecetaController.desactivarFormularioRecetas);

// Rutas Catalogo Medicamentos
router.get('/obtenerMedicamentos', auth.isAuthenticated, medicamentosController.obtenerMedicamentos);
router.post('/obtenerMed', auth.isAuthenticated, medicamentosController.obtenerMed);
//router.post('/editarMedicamento', auth.isAuthenticated, medicamentosController.editarMedicamento);
router.post('/editarMedicamento', auth.isAuthenticated,medicamentosController.editarMedicamento);
router.post('/agregarMedicamento',  auth.isAuthenticated,medicamentosController.agregarMedicamento);
router.post('/obtenerMedicamento', auth.isAuthenticated, medicamentosController.obtenerMedicamentoPorClave)
router.post('/eliminarMedicamento',  auth.isAuthenticated,medicamentosController.eliminarMedicamento);
router.post('/activarMedicamento',  auth.isAuthenticated,medicamentosController.activarMedicamento);

// Rutas Formulario Produccion
router.get('/formularioProduccion', auth.isAuthenticated, formularioProduccionController.formsProduccion);
router.post('/editarRecetaProduccion', auth.isAuthenticated, formularioProduccionController.editarRecetaProduccion);
router.post('/nuevoFormularioProduccion', auth.isAuthenticated, formularioProduccionController.addServicio);
router.post('/obtenerFormulariosProduccion', auth.isAuthenticated, formularioProduccionController.obtenerFormulariosProduccion);
router.post('/obtenerRecetaProduccion', auth.isAuthenticated, formularioProduccionController.obtenerRecetaProduccion);
router.post('/desactivarFormularioProduccion', auth.isAuthenticated, formularioProduccionController.desactivarFormularioProduccion);
router.post('/formularioFiltroProduccionExcel', auth.isAuthenticated, formularioProduccionController.getDataExcelProduccion);
// router.post('/login', (req,res)=>{
    //     if(process.env.ACTIVE_DIRECTORY=='true'){
        //         authController.apLoginAD(req,res)
        //     }else{
            //         authController.apLogin(req,res)
            //     }
            // });
            
            router.post('/login',authController.login);
            router.post('/psw', auth.isAuthenticated, authController.psw);
            router.get('/logout', authController.logout);
            
            router.get('/test-input', (req,res)=>{
                return res.render('tst');
            });
            

module.exports = router;