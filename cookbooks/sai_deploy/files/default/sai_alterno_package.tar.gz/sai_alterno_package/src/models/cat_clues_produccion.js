const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const cat_clues_produccion = dbConection.define('cat_clues_produccion',
    {
        clues:{
            type:  DataTypes.INTEGER,
            primaryKey: true
        },
        nombre:{
            type: DataTypes.STRING
        },
        nivel_atencion:{
            type: DataTypes.STRING
        },
    },
    {
        tableName: 'cat_clues_produccion', 
        freezeTableName: true ,
        createdAt: false,
        updatedAt: false
    }
    
);

cat_clues_produccion.removeAttribute('id');

module.exports = cat_clues_produccion;
