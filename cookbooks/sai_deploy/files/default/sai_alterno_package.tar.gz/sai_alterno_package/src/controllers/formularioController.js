const userModel = require("../models/users");
const CatalogModel = require("../models/CatalogModel");
const FormularioModel = require("../models/FormularioModel");
const bcrypt = require("bcrypt");
const fs = require("fs");
const path = require("path");
const getNombreEntidad = require('../util/diccionario');
const { renapoConsultarCurp } = require("../util/WebServices");
const { genCode, completarCedulaProfesional } = require("../util/util");
const { enviarEmail } = require("../util/util");
const PGconn = require("../config/postgressdb");
const { generarXLSFormulario } = require("../util/generarExcel");
const { stringify } = require("querystring");
const { Op } = require('sequelize');
const cat_clues = require("../models/cat_clues");
const cat_estados = require("../models/cat_estados");
const cat_medicamentos = require("../models/cat_medicamentos");
const bitacora = require("../models/bitacora");
const cat_estatus_bitacora = require("../models/cat_estatus_bitacora");

async function forms(req, res) {
  let usuarios = await userModel.findAll();
  let estados = global.catalogos.cat_entidad_federativa;
  let formulario = []
  // await FormularioModel.findAll({
  //   where: { estatus: true },
  // });
  let clue = "";

  if (req.usdata.fk_id_cat_type_users == 3) { // Filtracion de mostrar todo de la misma clue

    // formulario = await FormularioModel.findAll({
    //   where: { entidad_fed: String(req.usdata.fk_id_estado), clues: String(req.usdata.uname),estatus: true },

    // });

    estados = await cat_estados.findAll({ where: { id_estado: req.usdata.fk_id_estado } });
    clue = await userModel.findAll({ where: { uname: req.usdata.uname, fk_id_cat_type_users: String('3') } });
  } else if (req.usdata.fk_id_cat_type_users == 2) { // filtracion de mostrar visor estatal
    // formulario = await FormularioModel.findAll({
    //   where: { entidad_fed: String(req.usdata.fk_id_estado),estatus: true  },

    // });
    estados = await cat_estados.findAll({ where: { id_estado: req.usdata.fk_id_estado } });
    clue = await userModel.findAll({ where: { fk_id_cat_type_users: String('3'), fk_id_estado: String(req.usdata.fk_id_estado) } });

  }
  else if (req.usdata.fk_id_cat_type_users == 4 || req.usdata.fk_id_cat_type_users == 1) { // filtracion de mostrar visor general y 
    // formulario = await FormularioModel.findAll({
    //   where: { estatus: true },
    // });
    estados = global.catalogos.cat_entidad_federativa;
    clue = await userModel.findAll({ where: { fk_id_cat_type_users: String('3') } });
  }

  const formularioMapped = formulario.map(item => {
    return {
      ...item.dataValues,
      entidad_fed: getNombreEntidad(item.entidad_fed)
    };
  });
  // } else {
  // formulario = await FormularioModel.findAll();

  let buffer;
  if (formulario == null) {
    buffer = "";
    console.log("No hay formulario con datos");
    formulario = [];
  } else {
    // console.log('formulario',formulario);
    buffer = await generarXLSFormulario(formulario);

  }
  // buffer: buffer.toString("base64"),


  // console.log(formulario);
  try {

    res.render("formularioAcciones", {
      ...req.usdata,
      formulario: formularioMapped,
      cat_type_users: global.catalogos.cat_type_users,
      cat_entidades_admins: estados, //global.catalogos.cat_entidades_admins,
      sub_modulos: global.catalogos.sub_modulo, //sub_modulos,
      listaUsuarios: usuarios,
      directorio_activo: process.env.ACTIVE_DIRECTORY,
      buffer: buffer.toString("base64"),
      clues: clue,
    });
  } catch (error) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.adduser  ::' + error.message);
    console.error("--->>> usuariosController.adduser ");
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: "Error" });
  }
}


async function obtenerFormularios(req, res) {
  // --- DEBUGGING INICIO ---
  console.log('\n--- INICIO obtenerFormularios ---');
  console.log('req.body:', req.body);
  const { draw, start, length } = req.body;
  const searchValue = req.body.search.value;

  console.log('draw:', draw);
  console.log('start (recibido):', start);
  console.log('length (recibido):', length);
  console.log('searchValue:', searchValue);
  // --- DEBUGGING FIN ---

  // Convertir a números enteros y asegurar valores predeterminados seguros
  const offsetValue = parseInt(start, 10);
  const limitValue = parseInt(length, 10);

  const finalOffset = isNaN(offsetValue) || offsetValue < 0 ? 0 : offsetValue;
  const finalLimit = isNaN(limitValue) || limitValue <= 0 ? 10 : limitValue;

  console.log('start (parseado a int):', finalOffset);
  console.log('length (parseado a int):', finalLimit);

  const where = { estatus: true };
  let cluesCondition = null;

  // --- Lógica de usuario y CLUES ---
  if (req.usdata.fk_id_cat_type_users == 3) {
    console.log('Usuario tipo 3 detectado. req.usdata:', req.usdata);
    try {
      const oldCLUES = await userModel.getOldCLUES(req.usdata.id_user);
      console.log('oldCLUES desde userModel.getOldCLUES:', oldCLUES);
      where.entidad_fed = String(req.usdata.fk_id_estado);

      const cluesArr = [req.usdata.uname];
      if (oldCLUES?.clues_ssa && oldCLUES.clues_ssa !== '') {
        cluesArr.push(oldCLUES.clues_ssa);
      }
      cluesCondition = { clues: { [Op.or]: cluesArr } };
      console.log('cluesCondition para usuario tipo 3:', cluesCondition);

    } catch (cluesError) {
      console.error('ERROR al obtener oldCLUES:', cluesError.message, cluesError.stack);
      // Podrías decidir si detener aquí o continuar con un where.clues más simple
      // Por ahora, solo lo logueamos y la condición de clues no se aplicará si falla.
    }

  } else if (req.usdata.fk_id_cat_type_users == 2) {
    console.log('Usuario tipo 2 detectado. req.usdata:', req.usdata);
    where.entidad_fed = String(req.usdata.fk_id_estado);
  }
  // --- FIN Lógica de usuario y CLUES ---

  if (cluesCondition) {
    Object.assign(where, cluesCondition);
  }

  // Lógica de búsqueda global
  if (searchValue) {
    console.log('searchValue presente:', searchValue);
    where[Op.or] = [
      { id_formulario: { [Op.like]: `%${searchValue}%` } },
      { clave_institucion: { [Op.like]: `%${searchValue}%` } },
      { clues: { [Op.like]: `%${searchValue}%` } },
      { nombre_unidad: { [Op.like]: `%${searchValue}%` } },
      { tipo_unidad: { [Op.like]: `%${searchValue}%` } },
    ];
  }

  // --- DEBUGGING FINAL WHERE ---
  console.log('Cláusula WHERE final a aplicar:', JSON.stringify(where, null, 2));
  // --- DEBUGGING FINAL WHERE ---

  try {
    // 1. Conteo total (recordsTotal)
    const totalCountWhere = {
      estatus: true,
      ...(req.usdata.fk_id_cat_type_users == 3 && { entidad_fed: String(req.usdata.fk_id_estado), ...(cluesCondition ? { clues: cluesCondition.clues } : {}) }),
      ...(req.usdata.fk_id_cat_type_users == 2 && { entidad_fed: String(req.usdata.fk_id_estado) })
    };
    console.log('WHERE para totalCount:', JSON.stringify(totalCountWhere, null, 2));
    const totalCount = await FormularioModel.count({ where: totalCountWhere });
    console.log('recordsTotal (conteo total):', totalCount);

    // 2. Consulta paginada y filtrada (recordsFiltered y data)
    const { count: filteredCount, rows: paginatedFormularios } = await FormularioModel.findAndCountAll({
      where: where,
      order: [['id_formulario', 'ASC']],
      offset: finalOffset,
      limit: finalLimit,
    });
    console.log('recordsFiltered (conteo filtrado por findAndCountAll):', filteredCount);
    console.log('Número de registros devueltos en la página (paginatedFormularios.length):', paginatedFormularios.length);

    // Mapeo y transformación de datos
    const dataFormatted = paginatedFormularios.map(item => ({
      ...item.dataValues,
      entidad_fed: getNombreEntidad(item.entidad_fed), // Asegúrate que getNombreEntidad esté disponible
    }));
    console.log('Longitud de dataFormatted (datos finales):', dataFormatted.length);

    const respuesta = {
      draw: draw,
      recordsTotal: totalCount,
      recordsFiltered: filteredCount,
      data: dataFormatted
    };
    console.log('Respuesta JSON a enviar:', JSON.stringify(respuesta, null, 2));
    console.log('--- FIN obtenerFormularios ---\n');

    res.json(respuesta);
  } catch (error) {
    // --- MANEJO DE ERRORES CENTRALIZADO ---
    console.error('\n--- ERROR en obtenerFormularios ---');
    console.error('Mensaje de error:', error.message);
    console.error('Stack Trace:', error.stack); // Muy importante para ver dónde se originó el error
    console.error('req.body al momento del error:', req.body);
    console.error('--- FIN ERROR ---');

    res.status(500).json({
      error: 'Error interno del servidor al obtener formularios.',
      details: process.env.NODE_ENV === 'production' ? null : error.message // No envíes detalles en producción
    });
  }
}

async function obtenerFormulariosRecetas(req, res) {
  const respuesta = {
    draw: 1,
    recordsTotal: 0,
    recordsFiltered: 0,
    data: []
  }
  res.json(respuesta);
}
async function obtenerFormulariosMedicamentos(req, res) {
  const respuesta = {
    draw: 1,
    recordsTotal: 0,
    recordsFiltered: 0,
    data: []
  }
  res.json(respuesta);
}


async function addFormularioClue(req, res) {
  //let id_user =  req.usdata.id_user.toString();
  // console.log(req.body);
  const fecha_registro = req.body.fecha_registro;
  const hora_registro = req.body.hora_registro;
  const entidad_fed = [1, 4].includes(req.usdata.fk_id_cat_type_users) ?
    req.body.entidad_fed : req.usdata.fk_id_estado;
  const clues = [1, 2, 4].includes(req.usdata.fk_id_cat_type_users) ?
    req.body.clues : req.usdata.uname;
  const num_recetas_expedidas = req.body.num_recetas_expedidas;
  const num_recetas_negadas = req.body.num_recetas_negadas;
  const num_recetas_atendidas_parcialmente = req.body.num_recetas_atendidas_parcialmente;
  const num_recetas_atendidas_manera_completa = parseInt(req.body.num_recetas_atendidas_manera_completa);

  if (fecha_registro == '') {
    return res.json({ success: false, msg: 'Por favor ingresa una fecha válida' });
  }
  for (num of [num_recetas_atendidas_manera_completa, num_recetas_expedidas, num_recetas_negadas, num_recetas_atendidas_parcialmente]) {
    // console.log(num);
    if (num < 0 || isNaN(num)) {
      return res.json({ success: false, msg: 'Por favor ingresa un número válido' });
    }
  }

  try {
    const resultForm = await FormularioModel.addFormulario({
      fecha_registro: fecha_registro,
      hora_registro: hora_registro,
      entidad_fed: entidad_fed,
      clues: clues,
      num_recetas_expedidas: num_recetas_expedidas,
      num_recetas_negadas: num_recetas_negadas,
      num_recetas_atendidas_parcialmente: num_recetas_atendidas_parcialmente,
      num_recetas_atendidas_manera_completa: num_recetas_atendidas_manera_completa,
    });
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,1,'');
    if (!resultForm) {
      res
        .status(200)
        .json({
          success: true,
          error: 1,
          message: "Formulario generado correctamente",
        });
      return;
    }
  } catch (error) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.adduser  ::' + error.message);
    //console.error('--->>> usuariosController.adduser ');
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: "Error" });
  }
}

async function getDataExcel(req, res) {
  const { date1, date2 } = req.body;
  const dateCondition = {};

  if (date1 && date2) {
    dateCondition.fecha_registro = {
      [Op.between]: [new Date(date1), new Date(date2)]
    };
  }

  let formulario;

  if (req.usdata.fk_id_cat_type_users == 3) {
    const oldCLUES = await userModel.getOldCLUES(req.usdata.id_user);
    formulario = await FormularioModel.findAll({
      where: {
        entidad_fed: String(req.usdata.fk_id_estado),
        estatus: true,
        clues: (oldCLUES?.clues_ssa ?? '') != '' ? { [Op.or]: [req.usdata.uname, oldCLUES?.clues_ssa] } : req.usdata.uname,
        ...dateCondition
      },
    });

  } else if (req.usdata.fk_id_cat_type_users == 2) {
    formulario = await FormularioModel.findAll({
      where: {
        entidad_fed: String(req.usdata.fk_id_estado),
        estatus: true,
        ...dateCondition
      },
    });

  } else if (req.usdata.fk_id_cat_type_users == 4 || req.usdata.fk_id_cat_type_users == 1) {
    formulario = await FormularioModel.findAll({
      where: {
        estatus: true,
        ...dateCondition
      },
    });
  }

  if (formulario == null || formulario.length === 0) {
    console.log("No hay formulario con datos");
    return res.status(204).send(); // Sin contenido
  } else {
    try {
      const buffer = await generarXLSFormulario(formulario);
      res.setHeader('Content-Disposition', 'attachment; filename=formulario_excel.xlsx');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      return res.send(buffer);
    } catch (error) {
      console.error('Error al generar el archivo Excel:', error);
      return res.status(500).send('Error al generar el archivo Excel');
    }
  }
}

async function obtenerDataFormulario(req, res) {
  const id_formulario = req.body.id_formulario;

  const formulario = await FormularioModel.findOne({ where: { id_formulario: id_formulario } });
  if (!formulario) return; //No deberian poderse intentar con curp de no usuarios.
  res.json({
    success: true,
    data: {
      id_formulario: formulario.id_formulario,
      fecha_registro: formulario.fecha_registro,
      entidad_fed: formulario.entidad_fed,
      clues: formulario.clues,
      num_recetas_expedidas: formulario.num_recetas_expedidas,
      num_recetas_negadas: formulario.num_recetas_negadas,
      num_recetas_atendidas_parcialmente: formulario.num_recetas_atendidas_parcialmente,
      num_recetas_atendidas_manera_completa: formulario.num_recetas_atendidas_manera_completa,

    },
  });
}

async function editarPermisosFormulario(req, res) {
  let bitacoraEstatus = 1;
  let bitacoraRegistroAnterior = await FormularioModel.findByPk(parseInt(req.body.EditarIdFormulario));
  try {
    const id_formulario = req.body.EditarIdFormulario;
    const fecha_registro = req.body.EditarFecharRegistro.toString().trim();
    const entidad_fed = req.body.EditarEntidadFed ?? ''; //  Campo comentado en vista - Descomentar en caso de usarse
    const clues = req.body.EditarClues ?? ''; // Campo comentado en vista - Descomentar en caso de usarse
    const num_recetas_expedidas = req.body.EditarNumRecetasExpedidas;
    const num_recetas_negadas = req.body.EditarNumRecetasNegadas;
    const num_recetas_atendidas_parcialmente = req.body.EditarNumRecetasAtendidasParcialmente;
    const num_recetas_atendidas_manera_completa = req.body.EditarNumRecetasAtendidasManeraCompleta;

    for (num of [num_recetas_atendidas_manera_completa, num_recetas_expedidas, num_recetas_negadas, num_recetas_atendidas_parcialmente]) {
      console.log(num);
      if (num < 0 || isNaN(num)) {
        return res.json({ success: false, msg: 'Por favor ingresa un numero valido' });
      }
    }


    let resultUpdate = await FormularioModel.updateFormulario({
      id_formulario: id_formulario,
      fecha_registro: fecha_registro,
      entidad_fed: entidad_fed,
      clues: clues,
      num_recetas_expedidas: num_recetas_expedidas,
      num_recetas_negadas: num_recetas_negadas,
      num_recetas_atendidas_parcialmente: num_recetas_atendidas_parcialmente,
      num_recetas_atendidas_manera_completa: num_recetas_atendidas_manera_completa
    });
    let bitacoraRegistroActual = await FormularioModel.findByPk(parseInt(id_formulario));


    if (!resultUpdate) return; //No deberian poderse intentar con curp de no usuarios.
    console.log('Usuarios actualizados');
    let bitacoraCreate = await bitacora.create({
      fk_id_responsable: req.usdata.id_user,
      fk_id_registro_modificado: id_formulario,
      registro_antes: JSON.stringify(bitacoraRegistroAnterior),
      registro_despues: JSON.stringify(bitacoraRegistroActual),
      fk_id_estatus: bitacoraEstatus
    });

    res.json({ success: true });
  } catch (e) {
    console.error('--->>> usuariosController.editarPermisosUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}

async function desactivarFormulario(req, res) {
  let id_formulario = req.body.id;
  let bitacoraEstatus = 1;
  let bitacoraRegistroAnterior = await FormularioModel.findByPk(id_formulario);
  try {
    const id = req.body.id;
    //console.log('ID:', JSON.stringify(id));
    //const resultUpdate = FormularioModel.destroy({where:{ id_formulario: id }});
    const resultUpdate = await FormularioModel.findOne({ where: { id_formulario: id } });
    resultUpdate.estatus = false;
    await resultUpdate.save();
    let bitacoraRegistroActual = await FormularioModel.findByPk(parseInt(id_formulario));
    // console.log(resultUpdate);
    // await  registroBitacoraControl(id_user,'Administrador',curp,3,'');
    if (!resultUpdate) return; //No deberian poderse intentar con curp de no usuarios.
    let bitacoraCreate = await bitacora.create({
      fk_id_responsable: req.usdata.id_user,
      fk_id_registro_modificado: id_formulario,
      registro_antes: JSON.stringify(bitacoraRegistroAnterior),
      registro_despues: JSON.stringify(bitacoraRegistroActual),
      fk_id_estatus: bitacoraEstatus
    });
    res.json({ success: true, msg: 'Registro Eliminado' });
  } catch (e) {
    // await  registroBitacoraControl(id_user,'Administrador','',500,'usuariosController.deActiveUser  ::' + error.message);
    console.error('--->>> usuariosController.deActiveUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}



module.exports = {
  forms,
  obtenerFormularios,
  addFormularioClue,
  getDataExcel,
  obtenerDataFormulario,
  editarPermisosFormulario,
  desactivarFormulario,
  obtenerFormulariosRecetas,
  obtenerFormulariosMedicamentos,
};
