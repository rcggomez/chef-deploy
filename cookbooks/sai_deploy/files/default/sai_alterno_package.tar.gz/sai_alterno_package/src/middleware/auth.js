const userModel = require('../models/users');
const CatalogModel = require('../models/CatalogModel');
const jwt = require('jsonwebtoken');
const {promisify} = require('util')

async function isAuthenticated(req, res, next){
    // if (req.cookies[process.env.APP_COOKIE_NAME]) {
    //     try {
    //         const decoded = await promisify(jwt.verify)(req.cookies[process.env.APP_COOKIE_NAME], process.env.SECRET)
    //         userModel.findOne({ where: { id_user: decoded.id_user } })
    //         .then((data) => {
    //             req.usdata = data
    //             /*req.usdata.tipo_user = global.catalogos.cat_type_users[data.fk_id_tipo_user].type_user;
    //             req.usdata.nombre_entidad = global.catalogos.cat_entidades_admins[data.fk_id_entidad].fk_id_entidad;
    //             req.usdata.modulos=[];
    //             for(const id_sub_modulo of data._doc.permisos){
    //                 if(global.catalogos.sub_modulo[id_sub_modulo]){
    //                     req.usdata.modulos.push({
    //                         id_sub_modulo:id_sub_modulo,
    //                         ...global.catalogos.sub_modulo[id_sub_modulo]
    //                     });
    //                 }
    //             }*/
    //             return next(req,res)
    //         }).catch((error) => {
    //             console.log(error)
    //             res.redirect('/');
    //         });
    //     } catch (error) {
    //         console.log(error)
    //         res.redirect('/');
    //     }
    // } else {
    //     res.redirect('/');
    // }
    
  if (req.cookies[process.env.APP_COOKIE_NAME]) {
    try {
      const decoded = await promisify(jwt.verify)(
        req.cookies[process.env.APP_COOKIE_NAME],
        process.env.SECRET
      );

      if (decoded.id_user != '') {

        let data = await userModel.findOne({ where: { id_user: decoded.id_user } });
        //let dataLaboral = await usersInfoLaboral.findOne({ where: { fk_id_user: decoded.id_user } });
        // let datacomp = await complementariosModel.findOne({ fk_id_usereg: decoded.id_user });
        //let datareg = await registroModel.findOne({ fk_id_usereg: decoded.id_user });
        if (!data ) {
          throw new Error('Error mdl');//Si alguno de los datos no se recabo, entonces mal.
        }
        //req.usdata = data;
        req.usdata = data.dataValues;
        req.usdata.type_user = global.catalogos.cat_type_users.find(e=>e.id_cat_type_users==data.fk_id_cat_type_users).type_user;
        /*req.usdata.curp='Prueba';*/
        //req.usdata.tipo_user='Prueba';
        //req.usdata.tipo_user=dataLaboral.nombre_del_puesto;
        /*req.usdata.entidadnacimiento='Prueba';
        req.usdata.fechanac='Prueba';
        req.usdata.edad='Prueba';
        req.usdata.sexo='Prueba';*/
        req.usdata.modulos = await CatalogModel.getPermisos(data.id_user);
        /*req.usdata.modulos=[
          {
            'titulo': 'CAPTURAR FOTO',
            'descripcion': 'Gestion de los usuarios de la Plataforma',
            'picon': 'assets/img/menu/USUARIOS.svg',
            'visible': true,
            'rutas':[
              '/capturaFoto',
            ],
            'ordenamiento': 1,
            'f_reg': {
              '$date': '2024-01-11T00:00:00.000Z'
            }
          }
        ];*/

        //req.datareg = datareg;
        return next();
      } else {
        // bitacora(req.ip,0);
        res.redirect('/');
      }
    } catch (error) {
      console.error(error);
      res.redirect('/');//Se redirige por que es mejor que se haga algo a que no se haga nada
    }
  } else {
    // bitacora(req.ip,0);
    res.redirect('/');
  }
}

async function isAuthJson(req, res, next){
    if (req.cookies[process.env.APP_COOKIE_NAME]) {
        try {
            const decoded = await promisify(jwt.verify)(req.cookies[process.env.APP_COOKIE_NAME], process.env.SECRET)
            userAdminModel.findOne({ _id: decoded.id_user })
            .then((data) => {
                req.usdata = data
                return next()
            }).catch((error) => {
                console.log(error)
                res.json({success: false, msg: 'Su sesión ha finalizado', error: 1 });
            });
        } catch (error) {
            console.log(error)
            res.json({success: false, msg: 'Su sesión ha finalizado ', error: 2 });
        }
    } else {
        res.json({success: false, msg: 'Su sesión ha finalizado', error: 3 });
    }
}
// async function verificarPermiso(req, res, next){
//     if(req.usdata.modulos.find(e=>e.rutas.includes(req.url))!=undefined){
//         return next();
//     } else {
//         res.redirect('/');
//     }
// }
async function campass(req, res, next){
  if(process.env.ACTIVE_DIRECTORY=='true'){
    return next();
  } else{
    if(req.usdata.campass==false){
      return res.render('psw');
    } else{
      return next();
    }
  }
}

async function moduloRecetasHabilitado(req, res, next){
  let idModuloRecetas = 3;
  let modulo = req.usdata.modulos.find(e=>e.id_sub_modulo==idModuloRecetas);
  if(modulo!=undefined){
    return next();
  }
  res.redirect('/');
}
async function moduloMedicamentosHabilitado(req, res, next){
  let idModuloMedicamentos = 1;
  let modulo = req.usdata.modulos.find(e=>e.id_sub_modulo==idModuloMedicamentos);
  if(modulo!=undefined){
    return next();
  }
  res.redirect('/');
}


module.exports = {
    isAuthenticated,
    isAuthJson,
    // verificarPermiso,
    campass,
    moduloRecetasHabilitado,
    moduloMedicamentosHabilitado,
}