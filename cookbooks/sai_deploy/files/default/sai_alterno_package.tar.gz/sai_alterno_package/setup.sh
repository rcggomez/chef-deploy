#!/bin/bash

echo "🚀 Iniciando instalación de sai_alterno..."

# Configuraciones
APP_DIR="/opt/sai_alterno"
DB_NAME="db_sai_alterno"
DB_USER="postgres"
DB_PASS="admin"
DB_PORT="5432"
APP_PORT="30057"
SCHEMA_FILE="schema.sql"

# Instala dependencias del sistema
echo "🔧 Instalando Node.js, npm y PostgreSQL..."
sudo apt update && sudo apt install -y nodejs npm postgresql

# Crea la base de datos y usuario en PostgreSQL
echo "🗃️ Creando base de datos PostgreSQL..."
sudo -u postgres psql <<EOF
DROP DATABASE IF EXISTS $DB_NAME;
CREATE DATABASE $DB_NAME WITH OWNER $DB_USER;
EOF

# Restaura el esquema de base de datos
echo "📥 Restaurando esquema de base de datos desde $SCHEMA_FILE..."
sudo -u postgres psql -d $DB_NAME -f $SCHEMA_FILE

# Copia el código al directorio final
echo "📦 Copiando archivos de la aplicación a $APP_DIR..."
sudo mkdir -p $APP_DIR
sudo cp -r src certs package*.json $APP_DIR

# Establece permisos
sudo chown -R $USER:$USER $APP_DIR

# Instala dependencias Node.js
cd $APP_DIR
echo "📦 Instalando dependencias de Node.js..."
npm install

# Finaliza
echo "✅ Instalación completada. Puedes iniciar la app con:"
echo "cd $APP_DIR && npm start"

