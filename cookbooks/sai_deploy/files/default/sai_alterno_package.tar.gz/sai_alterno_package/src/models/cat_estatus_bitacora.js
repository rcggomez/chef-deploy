const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes, QueryTypes } = require('sequelize');

const cat_estatus_bitacora = dbConection.define('cat_estatus_bitacora',
  {
    id_cat_estatus_bitacora: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    decripcion: {
      type: DataTypes.STRING,
    },
  },
  {
    createdAt: false,
    updatedAt: false,
  }
);

module.exports = cat_estatus_bitacora;
