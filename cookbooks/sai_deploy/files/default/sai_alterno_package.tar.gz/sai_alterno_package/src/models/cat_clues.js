const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const cat_clues = dbConection.define('cat_clues',
    {
        id:{
            type:  DataTypes.INTEGER,
            primaryKey: true
        },
        'CLAVE DE LA INSTITUCION':{
            type: DataTypes.STRING
        },
        NOMBRE:{
            type: DataTypes.STRING
        },
        "CLAVE DE LA ENTIDAD":{
            type: DataTypes.STRING
        },
        "entidad":{
            type: DataTypes.STRING
        },
        "NIVEL ATENCION":{
            type: DataTypes.STRING
        }
    },
    {
        createdAt: false,
        updatedAt: false
    }
);

cat_clues.removeAttribute('id');

module.exports = cat_clues;
