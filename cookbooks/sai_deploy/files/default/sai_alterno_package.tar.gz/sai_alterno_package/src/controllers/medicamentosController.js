const userModel = require('../models/users');
const CatalogModel = require('../models/CatalogModel');
const bcrypt = require('bcrypt');
const fs = require('fs');
const path = require('path');
const { renapoConsultarCurp } = require('../util/WebServices');
const { genCode } = require('../util/util');
const { enviarEmail } = require('../util/util');
const PGconn = require('../config/postgressdb');
const cat_type_usersModel = require('../models/cat_type_users');
const cat_estados = require("../models/cat_estados");
const { Op } = require('sequelize');
const CatMedicamentos = require('../models/cat_medicamentos');
const bitacora = require('../models/bitacora');


async function obtenerMedicamentos(req, res) {

  console.log('obtenerMedicamentos');
// let usuarios = await userModel.findAll();
  let medicamentos = [];
  console.log(medicamentos)

  try {
    
    res.render('catalogoMedicamentos', {
      ...req.usdata,
      listaMedicamentos: medicamentos,
      userType: req.usdata.type_user
    });
  } catch (error) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.adduser  ::' + error.message);
    console.error('--->>> medicamentosController.medicamentos ');
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: 'Error' });
  }
}

async function obtenerMed(req, res) {
  const { draw, start, length } = req.body;
  const searchValue = req.body.search?.value || '';

  // Convertir a números enteros
  const offsetValue = parseInt(start, 10) || 0;
  const limitValue = parseInt(length, 10) || 10;

  const where = { estatus: true };

  // Agrega búsqueda global si hay un valor
  if (searchValue) {
    where[Op.or] = [
      { clave_sector_salud: { [Op.iLike]: `%${searchValue}%` } },
      { descripcion: { [Op.iLike]: `%${searchValue}%` } },
      { presentacion: { [Op.iLike]: `%${searchValue}%` } }
    ];
  }

  try {
    // Total sin filtros de búsqueda
    const totalCount = await CatMedicamentos.count({
      where: { estatus: true }
    });

    // Resultados filtrados y paginados
    const { count: filteredCount, rows: medicamentos } = await CatMedicamentos.findAndCountAll({
      where,
      order: [['clave_sector_salud', 'ASC']],
      offset: offsetValue,
      limit: limitValue
    });

    const dataFormatted = medicamentos.map(item => item.dataValues);

    const respuesta = {
      draw,
      recordsTotal: totalCount,
      recordsFiltered: filteredCount,
      data: dataFormatted
    };

    res.json(respuesta);
  } catch (error) {
    console.error('Error en obtenerMedicamentos:', error.message);
    console.error('Stack trace:', error.stack);
    res.status(500).json({ error: 'Error interno del servidor al obtener los medicamentos.' });
  }
}


async function adduser(req, res) {
  try {
    
    // if (process.env.ACTIVE_DIRECTORY == 'true') {
      //console.log('ruta de modulo ad activada');
      addUserNoAd(req, res);
    // } else {
    //   //console.log('ruta de modulo ad no activada');
    //   addUserNoAd(req, res);
    // }
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: 'Error' });
  }
}

async function addUserNoAd(req, res) {

  const curp = req.body.NuevoUsuarioCurpValidada.toString().trim() ?? null;
  const clue = req.body.NuevoClue.toString().trim();
  const correo = req.body.NuevoUsuarioCorreoConfirmar?.toString().toLowerCase().trim() ?? null;
  const tipo = req.body.NuevoUsuarioTipo;
  const nombre = req.body.NuevoUsuarioNombre;
  const telefono_fijo = req.body.NuevoUsuarioTelefonoFijo ?? ''; //  Campo comentado en vista - Descomentar en caso de usarse
  const telefono_celular = req.body.NuevoUsuarioTelefonoCelular ?? ''; // Campo comentado en vista - Descomentar en caso de usarse
  const fk_id_estado = req.body.NuevoUsuarioEntidad || null; // Campo comentado en vista - Descomentar en caso de usarse
  const primer_apellido = req.body.NuevoUsuarioPrimerA || null; //
  const segundo_apellido = req.body.NuevoUsuarioSegundoA || null; //Campo comentado en vista - Descoment
  let cluesValida = await userModel.findOne({where:{uname: req.body.NuevoClue.toString().trim()}}); 
  try {
    if(tipo == 3){
      if(!cluesValida){
        const passtemp = genCode();

        const saltRounds = 10;
        const salt = bcrypt.genSaltSync(saltRounds);
        const passws = passtemp;
        const hashedPass = bcrypt.hashSync(passws, salt);
        let resultClue = await userModel.addUser({
          tipo: tipo,
            nombre: nombre,
            primer_apellido: primer_apellido,
            segundo_apellido: segundo_apellido,
            email: clue,
            telefono_fijo: telefono_fijo,
            telefono_celular: telefono_celular,
            hashedPass: hashedPass,
            curp: curp,
            fk_id_estado: fk_id_estado,
        });
        const correoRegistrador = req.usdata.email;

        if(resultClue){
          const imagePathTop = path.join(
            __dirname,
            '../public/assets/avisos/FIRMA_CORREO_2.png'
          );
          const imagePathBottom = path.join(
            __dirname,
            '../public/assets/avisos/FIRMA_CORREO_1.png'
          );

          const imageContentTop = fs.readFileSync(imagePathTop, {
            encoding: 'base64',
          });
          const imageContentBottom = fs.readFileSync(imagePathBottom, {
            encoding: 'base64',
          });

          //console.log(imageContentTop);

          const asunto = 'DATOS DE ACCESO';
          const body = `<html>
                          <body>
                              <p>
                                  <div style="max-width:800px; margin:0 auto;">
                                      <img src="data:image/jpeg;base64,${imageContentTop}" style="max-width:100%; height:auto;">
                                      <div style="max-width:500px; margin:auto; font-family:Montserrat; color:#021B23;">
                                          <div style="height:4vh;"></div>
                                          <div style="margin:10px auto; font-weight:800; padding:6px; text-align:center;">
                                              <h2 style="font-weight:800; color:#235b4e; margin:0;">DATOS DE ACCESO</h2>
                                          </div>
                                          <div style="width:90%; margin:20px auto; text-align:justify;">
                                              <p>Bienvenido al registro de IMSS-BIENESTAR. Sus datos de inicio de sesión son los siguientes:</p>
                                              <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px 0; border-bottom:3px solid #B38E5D;">
                                                  <br aria-hidden="true">CORREO O CLUE: ${clue}
                                                  <br aria-hidden="true">CONTRASEÑA TEMPORAL: ${passtemp}
                                              </p>
                                              <p>Este usuario fue generado desde el sistema de registro IMSS-BIENESTAR.</p>
                                              <p>Puedes ingresar en el siguiente link:</p>
                                              <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px 0; border-bottom:3px solid #B38E5D;">  

                                              <a href="https://at-sai.imssbienestar.gob.mx/" style="color:#235b4e; text-decoration:none;">https://at-sai.imssbienestar.gob.mx//</a>

                                              </p>
                                              <p>Este Programa es público, ajeno a cualquier partido político. Queda prohibido el uso para fines distintos al desarrollo social.</p> 
                                          </div>
                                      </div>
                                      <img src="data:image/jpeg;base64,${imageContentBottom}" style="max-width:100%; height:auto;">
                                  </div>
                              </p>
                          </body>
                      </html>`;

          const mail = enviarEmail({
            to: correoRegistrador,
            to_name: nombre,
            subject: asunto,
            body: body,
            isHTml: true,
          });
          mail
            .then((resultado) => {
              console.log(resultado.msg);
              res.json({
                success: true,
                msg: 'Usuario creado y Correo Enviado exitosamente',
              });
            })
            .catch((error) => {
              console.error(error);
              res.status(200).json({ success: false, msg: 'Intente mas tarde.' });
              //console.error(error);
            });
          // res.status(200).json({ success: true, msg: 'Clue agregada correctamente.' });
        } else {
          // res.status(200).json({ success: false, msg: 'Intente más tarde.' });
        }
      } else if(cluesValida){
        res.json({ success: false, msg: 'Error, CLUES ya utilizada' });
      }
      
    } else {

      let userCurp = await userModel.findOne({ where: { curp: curp } });
      let userCorreo = await userModel.findOne({ where: { email: correo } });
  
      if (!userCurp && !userCorreo) {
        const passtemp = genCode();
        const saltRounds = 10;
        const salt = bcrypt.genSaltSync(saltRounds);
        const passws = passtemp;
        const hashedPass = bcrypt.hashSync(passws, salt);
        
  
        let resultAdmin = await userModel.addUser({
          tipo: tipo,
          nombre: nombre,
          primer_apellido: primer_apellido,
          segundo_apellido: segundo_apellido,
          email: correo,
          telefono_fijo: telefono_fijo,
          telefono_celular: telefono_celular,
          hashedPass: hashedPass,
          curp: curp,
          fk_id_estado: fk_id_estado,
        });
        // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,1,'');
  
        if (resultAdmin) {
          const imagePathTop = path.join(
            __dirname,
            '../public/assets/avisos/FIRMA_CORREO_2.png'
          );
          const imagePathBottom = path.join(
            __dirname,
            '../public/assets/avisos/FIRMA_CORREO_1.png'
          );
  
          const imageContentTop = fs.readFileSync(imagePathTop, {
            encoding: 'base64',
          });
          const imageContentBottom = fs.readFileSync(imagePathBottom, {
            encoding: 'base64',
          });
  
          //console.log(imageContentTop);
  
          const asunto = 'DATOS DE ACCESO';
          const body = `<html>
                          <body>
                              <p>
                                  <div style="max-width:800px; margin:0 auto;">
                                      <img src="data:image/jpeg;base64,${imageContentTop}" style="max-width:100%; height:auto;">
                                      <div style="max-width:500px; margin:auto; font-family:Montserrat; color:#021B23;">
                                          <div style="height:4vh;"></div>
                                          <div style="margin:10px auto; font-weight:800; padding:6px; text-align:center;">
                                              <h2 style="font-weight:800; color:#235b4e; margin:0;">DATOS DE ACCESO</h2>
                                          </div>
                                          <div style="width:90%; margin:20px auto; text-align:justify;">
                                              <p>Bienvenido al registro de IMSS-BIENESTAR. Sus datos de inicio de sesión son los siguientes:</p>
                                              <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px 0; border-bottom:3px solid #B38E5D;">
                                                  <br aria-hidden="true">USUARIO: ${correo}
                                                  <br aria-hidden="true">CONTRASEÑA TEMPORAL: ${passtemp}
                                              </p>
                                              <p>Este usuario fue generado desde el sistema de registro IMSS-BIENESTAR.</p>
                                              <p>Puedes ingresar en el siguiente link:</p>
                                              <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px 0; border-bottom:3px solid #B38E5D;">  
                                              <a href="https://at-sai.imssbienestar.gob.mx/" style="color:#235b4e; text-decoration:none;">https://at-sai.imssbienestar.gob.mx/</a>
                                              </p>
                                              <p>Este Programa es público, ajeno a cualquier partido político. Queda prohibido el uso para fines distintos al desarrollo social.</p> 
                                          </div>
                                      </div>
                                      <img src="data:image/jpeg;base64,${imageContentBottom}" style="max-width:100%; height:auto;">
                                  </div>
                              </p>
                          </body>
                      </html>`;
  
          const mail = enviarEmail({
            to: correo,
            to_name: nombre,
            subject: asunto,
            body: body,
            isHTml: true,
          });
          mail
            .then((resultado) => {
              console.log(resultado.msg);
              res.json({
                success: true,
                msg: 'Usuario creado y Correo Enviado exitosamente',
              });
            })
            .catch((error) => {
              console.error(error);
              res.status(200).json({ success: false, msg: 'Intente mas tarde.' });
              //console.error(error);
            });
          // sgMail
          //     .send(mail)
          //     .then(() => {
  
          //         console.log('Correo enviado con éxito');
          //         res.json({
          //             success: true,
          //             msg: 'Usuario creado y Correo Enviado exitosamente'
          //         });
          //     })
          //     .catch((error) => {
  
          //     });
        } else {
          res.status(200).json({ success: false, msg: 'Intente más tarde.' });
        }
      } else if (userCurp) {
        res.json({ success: false, msg: 'Error, CURP ya utilizada' });
      } else if (userCorreo) {
        res.json({ success: false, msg: 'Error, correo ya utilizado' });
      }
    }
  } catch (error) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.adduser  ::' + error.message);
    //console.error('--->>> usuariosController.adduser ');
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: 'Error' });
  }
}

async function adduserAD(req, res) {
  let id_user = req.usdata.id_user.toString();
  const curp = req.body.NuevoUsuarioCurpValidada.toString().trim();
  const correo = req.body.NuevoUsuarioCorreoConfirmar.toString().trim();
  const tipo = req.body.NuevoUsuarioTipo;
  const nombre = req.body.NuevoUsuarioNombre;
  const primer_apellido = req.body.NuevoUsuarioPrimerA;
  const segundo_apellido = req.body.NuevoUsuarioSegundoA;
  try {
    let userCurp = await userModel.findOne({ curp: curp });
    let userCorreo = await userModel.findOne({ correo: correo });
    if (!userCurp && !userCorreo) {
      // const passtemp = genCode();
      // const saltRounds = 10;
      // const salt = bcrypt.genSaltSync(saltRounds);
      // const passws = passtemp;
      // const hashedPass = bcrypt.hashSync(passws, salt);
      // console.log(passtemp);
      // console.log(hashedPass);

      let resultAdmin = await userModel.adduser({
        email: correo,
        hashedPass: '',
        tipo: tipo,
        nombre: nombre,
        primer_apellido: primer_apellido,
        segundo_apellido: segundo_apellido,
        curp: curp,
      });
      // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,1,'');

      if (resultAdmin) {
        const imagePathTop = path.join(
          __dirname,
          '../public/assets/avisos/FIRMA_CORREO_2.png'
        );
        const imagePathBottom = path.join(
          __dirname,
          '../public/assets/avisos/FIRMA_CORREO_1.png'
        );

        const imageContentTop = fs.readFileSync(imagePathTop, {
          encoding: 'base64',
        });
        const imageContentBottom = fs.readFileSync(imagePathBottom, {
          encoding: 'base64',
        });

        const body = `<div style="max-width:800px; justify-content: center;">
                    <img src="data:image/jpeg;base64,${imageContentTop} " style="max-width:800px;">
                    <br>
                    <div style="max-width:500px; max-height:700px; margin:auto; font-family:Montserrat">
                        <div style="color:#021B23">
                            <div style="height:4vh"></div>
                            <div style="margin:10px auto; font-weight:800; padding:6px; text-align:center">
                                <h2 style="font-weight:800; color:#235b4e; margin-bottom:0px; margin-top:0px">DATOS DE ACCESO</h2>
                            </div>
                            <div style="width:90%; margin:20px auto; text-align:justify">
                                <p>Bienvenido al registro de IMSS-BIENESTAR. Sus datos de inicio de sesion son los correspondientes a su cuenta institucional: </p>
                            <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px; border-bottom:3px solid #B38E5D">
                                <br aria-hidden="true">USUARIO:  ${correo}
                            </p>
                            <p> Este usuario fue generado desde el sistema de registro IMSS-BIENESTAR</p>
                            <p> Puedes Ingresdar en el siguiente link</p>
                            
                            <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px; border-bottom:3px solid #B38E5D">  
                               https://at-sai.imssbienestar.gob.mx/
                               </p>
                            <p>Este Programa es público, ajeno a cualquier partido político. Queda prohibido el uso para fines distintos al desarrollo social.</p> 
                            </div>
                        </div>
                    </div>
                    <br>
                    <img src="data:image/jpeg;base64, ${imageContentBottom} " style="max-width:800px;">
                </div>`;

        sgMail.setApiKey(process.env.MAIL_APIKEY_SENDGRID);

        const asunto = 'DATOS DE ACCESO';

        const msg = {
          to: correo,
          from: process.env.MAIL_ORIGIN,
          subject: asunto,
          html: '<p>' + body + '</p>',
        };

        sgMail
          .send(msg)
          .then(() => {
            console.log('Correo enviado con éxito');
            res.json({
              success: true,
              msg: 'Usuario creado y Correo Enviado exitosamente',
            });
          })
          .catch((error) => {
            console.error(error);
            res.status(200).json({ success: false, msg: 'Intente mas tarde.' });
          });
      } else {
        res.status(200).json({ success: false, msg: 'Intente más tarde.' });
      }
    } else if (userCurp) {
      res.json({ success: false, msg: 'Error, CURP ya utilizada' });
    } else if (userCorreo) {
      res.json({ success: false, msg: 'Error, correo ya utilizado' });
    }
    /*let userCurp = await userAdminModel.findOne({curp: req.body.NuevoUsuarioCurpValidada});
    let userCorreo = await userAdminModel.findOne({correo: req.body.NuevoUsuarioCorreoConfirmar});
    if(!userCurp && !userCorreo){
        const passtemp = genCode();
        const saltRounds = 10;
        const salt = bcrypt.genSaltSync(saltRounds);
        const passws = passtemp;
        const hashedPass = bcrypt.hashSync(passws, salt);
        //console.log(hashedPass);
        const newAdmin = new userAdminModel({
            nombre          :   req.body.NuevoUsuarioNombre,
            paterno         :   req.body.NuevoUsuarioPrimerA,
            materno         :   req.body.NuevoUsuarioSegundoA,
            curp            :   req.body,
            correo          :   req.body.NuevoUsuarioCorreoConfirmar,
            telefono        :   req.body.NuevoUsuarioTelefonoConfirmar,
            user            :   req.body.NuevoUsuarioCorreoConfirmar,
            pass            :   hashedPass,
            fk_id_tipo_user :   req.body.NuevoUsuarioTipo
        });
      
        const resultAdmin = await newAdmin.save();
        if(resultAdmin){
            res.json({ success: true, msg: 'Guardado'});
        } else{
            res.json({ success: false, msg: 'Error al guardar'});
        }
    } else if(userCurp){
        res.json({ success: false, msg: 'Error, CURP ya utilizada'});
    }else if(userCorreo){
        res.json({ success: false, msg: 'Error, correo ya utilizado'});
    } else {
        res.json({ success: false, msg: 'Error'});
    }*/
  } catch (error) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.adduser  ::' + error.message);
    console.error('--->>> usuariosController.adduser ');
    console.error(error);
    res.status(500).json({ success: false, error: 1, message: 'Error' });
  }

  /*let userCurp = await userAdminModel.findOne({curp: req.body.NuevoUsuarioCurpValidada});
    let userCorreo = await userAdminModel.findOne({correo: req.body.NuevoUsuarioCorreoConfirmar});
    if(!userCurp && !userCorreo){
        const passtemp = genCode();
        const saltRounds = 10;
        const salt = bcrypt.genSaltSync(saltRounds);
        const passws = passtemp;
        const hashedPass = bcrypt.hashSync(passws, salt);
        //console.log(hashedPass);
        const newAdmin = new userAdminModel({
            nombre          :   req.body.NuevoUsuarioNombre,
            paterno         :   req.body.NuevoUsuarioPrimerA,
            materno         :   req.body.NuevoUsuarioSegundoA,
            curp            :   req.body,
            correo          :   req.body.NuevoUsuarioCorreoConfirmar,
            telefono        :   req.body.NuevoUsuarioTelefonoConfirmar,
            user            :   req.body.NuevoUsuarioCorreoConfirmar,
            pass            :   hashedPass,
            fk_id_tipo_user :   req.body.NuevoUsuarioTipo
        });
      
        const resultAdmin = await newAdmin.save();
        if(resultAdmin){
            res.json({ success: true, msg: 'Guardado'});
        } else{
            res.json({ success: false, msg: 'Error al guardar'});
        }
    } else if(userCurp){
        res.json({ success: false, msg: 'Error, CURP ya utilizada'});
    }else if(userCorreo){
        res.json({ success: false, msg: 'Error, correo ya utilizado'});
    } else {
        res.json({ success: false, msg: 'Error'});
    }*/
}

async function NuevoUsuarioValidarCurp(req, res) {
  let consultaCurp = await renapoConsultarCurp(req.body.curp);
  if (consultaCurp) {
    res.json({
      success: true,
      msg: 'CURP VALIDO',
      data: {
        curp: consultaCurp.curpResponse,
        primerA: consultaCurp.primerA,
        segundoA: consultaCurp.segundoA,
        nombre: consultaCurp.nombre,
        //fechaNac:consultaCurp.fechaNac,
      },
    });
  } else {
    res.json({ success: false, msg: 'CURP NO ENCONTRADO' });
  }
}

async function getUsers(req, res) {}

async function obtenerPermisosUser(req, res) {
  const id_user = req.body.id_user;

  const usuario = await userModel.findOne({ where: { id_user: id_user } });
  // console.log(usuario);
  if (!usuario) return; //No deberian poderse intentar con curp de no usuarios.
  res.json({
    success: true,
    data: {
      clues: usuario.uname,
      tipo: usuario.fk_id_cat_type_users,
      nombre: usuario.nombre,
      primerA: usuario.primer_apellido,
      segundoA: usuario.segundo_apellido,
      curp: usuario.curp,
      correo: usuario.email,
      permisos: await CatalogModel.getPermisos(usuario.id_user),
      entidad: usuario.fk_id_estado,
    },
  });
}

async function editarPermisosUser(req, res) {
  //console.log(req.body);
  try {
    const id_user = req.body.EditarPermisosIdUser.toString();
    const email = req.body.EditarPermisosCorreo.toString().trim();
    const telefono_fijo = req.body.EditarPermisosTelefonoCelular ?? ''; //  Campo comentado en vista - Descomentar en caso de usarse
    const telefono_celular = req.body.EditarPermisosTelefonoFijo ?? ''; // Campo comentado en vista - Descomentar en caso de usarse
    const permisosUsuario = await CatalogModel.getPermisos(id_user);
    let formKeys = Object.keys(req.body);
    let sub_modulos = formKeys.filter((e) => e.includes('EditarPermisos_'));
    let permisos = [];
    sub_modulos.forEach((e) =>
      permisos.push(+e.replace('EditarPermisos_', ''))
    );

    // Crear un nuevo array con solo los valores de id_sub_modulo en permisosUsuario
    const permisosUsuarioIds = permisosUsuario.map(
      (permiso) => permiso.id_sub_modulo
    );
    // Verificar si todos los elementos de permisosUsuarioIds están presentes en permisos
    const todosPresentes = permisos.every(permiso => permisosUsuarioIds.includes(permiso))
      && permisosUsuarioIds.every(permiso => permisos.includes(permiso));
    
    

    let resultUpdate = await userModel.updateUser({
      id_user: id_user,
      email: email,
      telefono_fijo: telefono_fijo,
      telefono_celular: telefono_celular,
      permisos: permisos,
      permisosUsuario: permisosUsuarioIds,
      todosPermisosPresentes: todosPresentes
    });

    
    if (!resultUpdate) return; //No deberian poderse intentar con curp de no usuarios.
    console.log('Usuarios actualizados');
    res.json({ success: true });
  } catch (e) {
    console.error('--->>> usuariosController.editarPermisosUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}

async function deActiveUser(req, res) {
  let id_user = req.usdata.id_user.toString();
  try {
    const id = req.body.id;
    //console.log('ID:', JSON.stringify(id));
    const resultUpdate = userModel.update(
      { activo: false },
      { where: { id_user: id } }
    );

    // console.log(resultUpdate);
    // await  registroBitacoraControl(id_user,'Administrador',curp,3,'');
    if (!resultUpdate) return; //No deberian poderse intentar con curp de no usuarios.
    res.json({ success: true, msg: 'Usuario Desactivado' });
  } catch (e) {
    // await  registroBitacoraControl(id_user,'Administrador','',500,'usuariosController.deActiveUser  ::' + error.message);
    console.error('--->>> usuariosController.deActiveUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}

async function reActiveUser(req, res) {
  let id_user = req.usdata.id_user.toString();
  try {
    const id = req.body.id;

    const resultUpdate = userModel.update(
      { activo: true },
      { where: { id_user: id } }
    );

    // await  registroBitacoraControl(id_user,'Administrador',id,4,'');
    if (!resultUpdate) return; //No deberian poderse intentar con curp de no usuarios.
    res.json({ success: true, msg: 'Usuario Reactivado' });
  } catch (e) {
    // await  registroBitacoraControl(id_user,'Administrador','',500,'usuariosController.reActiveUser  ::' + error.message);
    console.error('--->>> usuariosController.reActiveUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}

async function actualizarContrasenaUser(req, res) {
  let id_user = req.usdata.id_user.toString();
  try {
    const id = req.body.id;

    const data = await userModel.findOne({ where: { id_user: id } });

    console.log(data);
    if (data) {
      const passtemp = genCode();

      const saltRounds = 10;
      const salt = bcrypt.genSaltSync(saltRounds);
      const passws = passtemp;
      const hashedPass = bcrypt.hashSync(passws, salt);
      const correo = data.email;
      const nombre = data.nombre;
      const resultUpdate = await userModel.update(
        { upass: hashedPass, campass: false },
        { where: { id_user: id } } 
      );
      if(data.fk_id_cat_type_users == 3){
        res.json({ success: true, data:{'nombre': nombre, 'passtemp': passtemp}  });
      } else {
          const imagePathTop = path.join(
          __dirname,
          '../public/assets/avisos/FIRMA_CORREO_2.png'
          );
          const imagePathBottom = path.join(
            __dirname,
            '../public/assets/avisos/FIRMA_CORREO_1.png'
          );

          const imageContentTop = fs.readFileSync(imagePathTop, {
            encoding: 'base64',
          });
          const imageContentBottom = fs.readFileSync(imagePathBottom, {
            encoding: 'base64',
          });

          const body = `<div style="max-width:800px; justify-content: center;">
                          <img src="data:image/jpeg;base64,${imageContentTop} " style="max-width:800px;">
                          <br>
                          <div style="max-width:500px; max-height:700px; margin:auto; font-family:Montserrat">
                              <div style="color:#021B23">
                                  <div style="height:4vh"></div>
                                  <div style="margin:10px auto; font-weight:800; padding:6px; text-align:center">
                                      <h2 style="font-weight:800; color:#235b4e; margin-bottom:0px; margin-top:0px">DATOS DE ACCESO</h2>
                                  </div>
                                  <div style="width:90%; margin:20px auto; text-align:justify">
                                      <p>Bienvenido al registro de IMSS-BIENESTAR. Sus datos de inicio de sesion son los siguientes: </p>
                                  <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px; border-bottom:3px solid #B38E5D">
                                      <br aria-hidden="true">USUARIO:  ${correo}
                                      <br aria-hidden="true">CONTRASEÑA TEMPORAL:  ${passtemp}
                                  </p>
                                  <p>Este usuario fue generado desde el sistema de registro IMSS-BIENESTAR</p>
                                  <p style="text-align:center; font-weight:700; font-size:1.1rem; margin:20px; border-bottom:3px solid #B38E5D">  
                                  Link de ingreso: https://at-sai.imssbienestar.gob.mx/
                                  </p>
                              <p >Este Programa es público, ajeno a cualquier partido político. Queda prohibido el uso para fines distintos al desarrollo social.</p> 
                              
                                  </div>
                              </div>
                          </div>
                          <br>
                          <img src="data:image/jpeg;base64, ${imageContentBottom} " style="max-width:800px;">
                      </div>`;

          //sgMail.setApiKey(process.env.MAIL_APIKEY_SENDGRID);

          const asunto = 'DATOS DE ACCESO';

          const mail = enviarEmail({
            to: correo,
            to_name: nombre,
            subject: asunto,
            body: body,
            isHTml: true,
          });

          mail
            .then((resultado) => {
              // console.log(resultado.msg);
              res.json({
                success: true,
                msg: 'Contraseña actualizada y Correo Enviado exitosamente' ,
                data:{'nombre': nombre, 'passtemp': passtemp}
              });
            })
            .catch((error) => {
              console.error(error);
              res.status(200).json({ success: false, msg: 'Intente mas tarde.' });
              //console.error(error);
            });
          // sgMail
          //     .send(msg)
          //     .then(() => {

          //         console.log('Correo enviado con éxito');

          //         return res.json({
          //             success: true,
          //             msg: 'Contraseña actualizada y Correo Enviado exitosamente'
          //         });

          //     })
          //     .catch((error) => {
          //         session.abortTransaction();
          //         session.endSession();
          //         console.error(error);
          //         return res.status(200).json({ success: false, msg: 'Intente mas tarde.' });
          //     });
      }
      
      // if (resultUpdate) {
      //   // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,5,'');
     
      // } else {
      //   res.status(200).json({ success: false, msg: 'Intente más tarde.' });
      // }
    } else {
      return res
        .status(200)
        .json({ success: false, msg: 'CURP no encontrado.' });
    }
  } catch (e) {
    // await  registroBitacoraControl(id_user,'Administrador',req.body.NuevoUsuarioCurpValidada,500,'usuariosController.actualizarContrasenaUser  ::' + error.message);
    console.error('--->>> usuariosController.actualizarContrasenaUser ');
    console.error(e.message);
    res.json({ success: false, msg: 'Error' });
  }
}

async function editarMedicamento(req, res) {
  let response = { success: false, msg: '', data: []};

  if(req.usdata.fk_id_cat_type_users !== 1){
    response.msg = "Usuario no válido";
    return res.status(400).json(response)
  }
  //Se añade status 3 para edición de medicamento en bitacora
  let bitacoraEstatus =3;
  //Debe mandarse toda la info desde el front
  const { clave_sector_salud, descripcion, presentacion, precio, estatus } = req.body;

  //Validaciones de datos recibidos por el front
  if (!clave_sector_salud || !descripcion || !presentacion ) {
    response.msg = "Todos los campos son obligatorios";
    return res.status(400).json(response);
  }

  //Validaciones de tipos correctos de datos recibidos
  if((typeof clave_sector_salud !== "string") || clave_sector_salud.length < 12 || clave_sector_salud.length > 15){
    response.msg = "La clave del medicamento debe tener entre 12 y 15 caracteres";
    return res.status(400).json(response);
  }
if(typeof descripcion !== "string"){
  response.msg = "Se espera dato de tipo string"
  return res.status(400).json(response);
}
if(typeof presentacion !== "string"){
  response.msg = "Se espera dato de tipo string"
  return res.status(400).json(response);
}


  try{
    //Obtenemos el registro anterior del medicamento
    //Podemos reutilizar este mismo
    let medicamentoAnterior = await CatMedicamentos.findOne({
      where: {clave_sector_salud: clave_sector_salud}
    })
    console.log("Medicamento anterior:", medicamentoAnterior.toJSON());
    if(!medicamentoAnterior){
      response.msg = "No se encontró el medicamento";
      return res.status(404).json(response);
    }

    //Actualizacion del medicamento con los datos nuevos y la bitacora
    let created_at = new Date().now ; 

    //Se manda actualizacion del medicamento
    medicamento = await CatMedicamentos.update({
      descripcion: descripcion,
      presentacion: presentacion,
      estatus: estatus,
      precio: precio,
      created_at: created_at
    }, {
      where: {clave_sector_salud: clave_sector_salud}
    });

    //Obtenemos el registro actualizado para poder retornarlo al front o respuesta de api/endpoint
    let medicamentoEditado = await CatMedicamentos.findOne({
      where: {clave_sector_salud: clave_sector_salud}
    });
    console.log("Medicamento editado:", medicamentoEditado.toJSON());
    //Registramos en la bitacora
    //Recordar generar registro en bd del nuevo estatus 3 y 4 para editar y agregar medicamento
    let idmedicamento = parseInt(medicamentoEditado.clave_sector_salud);
    await bitacora.create({
      fk_id_responsable: req.body.id_user || req.usdata.id_user  || 1,
      fk_id_registro_modificado: idmedicamento,
      registro_antes: JSON.stringify(medicamentoAnterior),
      registro_despues: JSON.stringify(medicamentoEditado),
      fk_id_estatus: bitacoraEstatus
    });


    response.edited = medicamentoEditado
      console.log("Termina editarMedicamentos--------------------------------------------------------");
      response.msg = "Medicamento encontrado, procediendo a editar";
      response.success = true;
    return res.status(201).json(response);
  }catch(error){
    console.log('Error al editar el medicamento: ' + error);
      console.log("Termina editarMedicamentos--------------------------------------------------------");
    return res.json(response);
  }

}

async function agregarMedicamento(req, res){
  console.log("Comienza agregarMedicamentos--------------------------------------------------------");
  
  const { clave_sector_salud, descripcion, presentacion, precio, estatus } = req.body;
  let response = { success: false, msg: '', data: [] };

  
  if (!clave_sector_salud || !descripcion || !presentacion ) {
    response.msg = "Todos los campos son obligatorios";
    return res.status(400).json(response);
  }
  if (typeof clave_sector_salud !== "string" || clave_sector_salud.length < 12 || clave_sector_salud.length > 15) {
    response.msg = "La clave del medicamento debe tener entre 12 y 15 caracteres";
    return res.status(400).json(response);
  }
  if (typeof descripcion !== "string" || typeof presentacion !== "string" || typeof precio !== "string") {
    response.msg = "Descripción, presentación y precio deben ser texto";
    return res.status(400).json(response);
  }
  // if(req.usdata.fk_id_cat_type_users !== 1){
  //   response.msg ="Usuario no válido";
  //   return res.status(400).json(response);
  // }
  let tipoUsuario = req.usdata?.fk_id_cat_type_users || (req.body.id_user === 1 ? 1 : null);
  if(tipoUsuario !== 1){
    response.msg ="Usuario no válido";
    return res.status(400).json(response);
  }

  try {
    let medicamento = await CatMedicamentos.findOne({
      where: { clave_sector_salud: clave_sector_salud }
    });
    if (medicamento) {
      response.msg = 'Medicamento ya existe';
      return res.status(400).json(response);
    }
    let created_at = new Date();
    medicamento = await CatMedicamentos.create({
      clave_sector_salud,
      descripcion,
      presentacion,
      precio
    });
    response.success = true;
    response.data = medicamento;
    return res.status(201).json(response);
  } catch (error) {
    console.log('Error al agregar el medicamento: ' + error);
    response.msg = 'Error al agregar el medicamento';
    return res.status(500).json(response);
  }
}

async function eliminarMedicamento(req, res){
  let response = { success: false, msg: '', data: []};
  console.log("Comienza eliminarMedicamentos--------------------------------------------------------");
  console.log(req.body);
  const { clave_sector_salud } = req.body;
  console.log("Clave del medicamento:", clave_sector_salud);

  if(!clave_sector_salud ){
    response.msg = "La clave del medicamento es obligatoria";
    return res.status(400).json(response);
  }
    let tipoUsuario = req.usdata?.fk_id_cat_type_users || (req.body.id_user === 1 ? 1 : null);
  if(tipoUsuario !== 1){
    response.msg ="Usuario no válido";
    return res.status(400).json(response);
  }
  try{
    let medicamentoAnterior = await CatMedicamentos.findOne({
      where: { clave_sector_salud: clave_sector_salud }
    });
    if(!medicamentoAnterior){
      response.msg = "Medicamento no encontrado";
      return res.status(404).json(response);
    }
    let estado = false;
    medicamento = await CatMedicamentos.update({
      estatus: estado
    }, {
      where: { clave_sector_salud: clave_sector_salud }
    });

    let medicamentoEliminado = await CatMedicamentos.findOne({
      where: { clave_sector_salud: clave_sector_salud }
    });
    console.log("Medicamento eliminado:", medicamentoEliminado.toJSON());

    let idmedicamento = parseInt(medicamentoEliminado.clave_sector_salud);
    await bitacora.create({
      fk_id_responsable: req.body.id_user || req.usdata.id_user  || 1,
      fk_id_registro_modificado: idmedicamento,
      registro_antes: JSON.stringify(medicamentoAnterior),
      registro_despues: JSON.stringify(medicamentoEliminado),
      fk_id_estatus: 4 //Estatus 4 para eliminar medicamento
    });

    response.eliminado = medicamentoEliminado;
    response.success = true;
    return res.status(200).json(response);
  }catch(error){
    console.log('Error al eliminar el medicamento: ' + error);
    response.msg = 'Error al eliminar el medicamento';
    return res.status(500).json(response);
  }
}

async function activarMedicamento(req, res){
  let response = { success: false, msg: '', data: []};
  console.log("Comienza activarMedicamentos--------------------------------------------------------");

  const { clave_sector_salud } = req.body;

  if(!clave_sector_salud ){
    response.msg = "La clave del medicamento es obligatoria";
    return res.status(400).json(response);
  }
    let tipoUsuario = req.usdata?.fk_id_cat_type_users || (req.body.id_user === 1 ? 1 : null);
  if(tipoUsuario !== 1){
    response.msg ="Usuario no válido";
    return res.status(400).json(response);
  }
  try{
    let medicamentoAnterior = await CatMedicamentos.findOne({
      where: { clave_sector_salud: clave_sector_salud }
    });
    if(!medicamentoAnterior){
      response.msg = "Medicamento no encontrado";
      return res.status(404).json(response);
    }
    let estado = true;
    medicamento = await CatMedicamentos.update({
      estatus: estado
    }, {
      where: { clave_sector_salud: clave_sector_salud }
    });

    let medicamentoEliminado = await CatMedicamentos.findOne({
      where: { clave_sector_salud: clave_sector_salud }
    });
    console.log("Medicamento activado:", medicamentoEliminado.toJSON());

    let idmedicamento = parseInt(medicamentoEliminado.clave_sector_salud);
    await bitacora.create({
      fk_id_responsable: req.body.id_user || req.usdata.id_user  || 1,
      fk_id_registro_modificado: idmedicamento,
      registro_antes: JSON.stringify(medicamentoAnterior),
      registro_despues: JSON.stringify(medicamentoEliminado),
      fk_id_estatus: 4 //Estatus 4 para eliminar medicamento
    });

    response.eliminado = medicamentoEliminado;
    return res.status(200).json(response);
  }catch(error){
    console.log('Error al activar el medicamento: ' + error);
    response.msg = 'Error al activar el medicamento';
    return res.status(500).json(response);
  }
}

async function obtenerMedicamentoPorClave(req, res) {
  const { clave_sector_salud } = req.body;
  let response = { success: false, msg: '', data: []};
  try {
    const medicamento = await CatMedicamentos.findOne({
      where: { clave_sector_salud }
    });
    if(!medicamento) {
      response.msg = 'Medicamento no encontrado';
      return res.status(404).json(response);
    }
    response.success = true;
    response.data = medicamento;
    return res.json(response)
  } catch (error) {
    console.error('Error al obtener el medicamento:', error);
    return res.status(500).json(response);
  }
}

module.exports = {
  obtenerMedicamentos,
  obtenerMed,
  editarMedicamento,
  agregarMedicamento,
  eliminarMedicamento,
  activarMedicamento,
  obtenerMedicamentoPorClave
};
