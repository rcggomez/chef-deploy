const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes ,QueryTypes  } = require('sequelize');

function getPermisos(id_user){
    return dbConection.query(`SELECT id_sub_modulo, archivo, titulo  AS legend, picon
        FROM rutas r
        LEFT JOIN sub_modulo s on s.fk_id_ruta = r.id_ruta
        LEFT JOIN rel_users_sub_modulo ru on ru.fk_id_sub_modulo = s.id_sub_modulo
        WHERE ru.fk_id_user = $1 AND r.vigente IS TRUE AND ru.vigente IS TRUE
        ORDER BY ordenamiento ASC;`, {
        type: QueryTypes.SELECT,
        bind: [id_user]
        });
}

module.exports = {
    getPermisos,
}