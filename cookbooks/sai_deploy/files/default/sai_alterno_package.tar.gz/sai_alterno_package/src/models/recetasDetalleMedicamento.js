const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const recetasDetalleMedicamento = dbConection.define('recetas_detalle_medicamento',
    {
        id:{
            type:  DataTypes.INTEGER,
            primaryKey: true
        },
        fk_id_receta: {
            type: DataTypes.INTEGER,
            //allowNull: false,
            /* references: {
                model: 'recetas',
                key: 'id_receta',
            },
            onDelete: 'RESTRICT', */
        },
        fk_id_medicamento: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        cantidad_receptida: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        cantidad_expedida: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        estatus: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        fraccionado: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        created_at:{
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        }
    },
    {
        createdAt: false,
        updatedAt: false,
        tableName: 'recetas_detalle_medicamento'
    }
    
);
// FormularioUnidadHospitalariaModel.sync({force:true})
recetasDetalleMedicamento.removeAttribute('id');

module.exports = recetasDetalleMedicamento;
