const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes, QueryTypes } = require('sequelize');

const bitacora = dbConection.define('bitacora',
  {
    id_bitacora: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    fk_id_responsable: {
      type: DataTypes.INTEGER,
      //allowNull: false,
      references: {
        model: 'users',
        key: 'id_user',
      },
      onDelete: 'RESTRICT',
    },
    fk_id_registro_modificado: {
      type: DataTypes.INTEGER,
    },
    registro_antes: {
      type: DataTypes.STRING,
    },
    registro_despues: {
      type: DataTypes.STRING,
    },
    fecha_actualizacion: {
      type: 'TIMESTAMP',
      allowNull: false,
      defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
    },
    fk_id_estatus: {
      type: DataTypes.INTEGER,
       //allowNull: false,
      references: {
        model: 'cat_estatus_bitacora',
        key: 'id_cat_estatus_bitacora',
      },
      onDelete: 'RESTRICT',
    },
  },
  {
    freezeTableName: true,
    createdAt: false,
    updatedAt: false,
  }
);

module.exports = bitacora;
