const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const catMedicamentos = dbConection.define('cat_medicamentos',
    {
        clave_sector_salud:{
            type:  DataTypes.STRING,
            primaryKey: true
        },
        descripcion:{
            type: DataTypes.STRING
        },
        presentacion:{
            type: DataTypes.STRING
        },
        precio:{
            type: DataTypes.STRING
        },
        estatus: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        created_at:{
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        }
    },
    {
        createdAt: false,
        updatedAt: false
    }
);

catMedicamentos.removeAttribute('id');

module.exports = catMedicamentos;
