const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const recetas = dbConection.define('recetas',
    {
        id_receta:{
            type:  DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        entidad_fed: {
            type: DataTypes.INTEGER,
            //allowNull: false,
            references: {
                model: 'cat_estados',
                key: 'id_estado',
            },
            onDelete: 'RESTRICT',
        },
        clues: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        fecha_preescripcion: {
            type: DataTypes.DATE,
            defaultValue: true
        },
        fecha_surtimiento: {
            type: DataTypes.DATE,
            defaultValue: true
        },
        folio: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        fecha_creacion:{
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: 'NOW()',
        },
        receta_comunitaria: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        estatus: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue:true
        }
    },
    {
        createdAt: false,
        updatedAt: false
    }
);
// FormularioUnidadHospitalariaModel.sync({force:true})
recetas.removeAttribute('id');

module.exports = recetas;
