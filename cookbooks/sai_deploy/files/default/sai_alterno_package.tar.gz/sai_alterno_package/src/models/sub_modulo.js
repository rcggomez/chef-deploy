const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const sub_moduloModel = dbConection.define('sub_modulo',
    {
        id_sub_modulo: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        titulo: {
            type: DataTypes.STRING,
        },
        descripcion: {
            type: DataTypes.STRING,
        },
        fk_id_modulo: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'modulos',
                key: 'id_modulo',
            },
            onDelete: 'RESTRICT',
        },
        picon: {
            type: DataTypes.STRING,
        },
        manual: {
            type: DataTypes.STRING,
        },
        visible:{
            type: DataTypes.BOOLEAN,
        },
        fk_id_ruta: {
            type: DataTypes.INTEGER,
            //allowNull: false,
            references: {
                model: 'rutas',
                key: 'id_ruta',
            },
            onDelete: 'RESTRICT',
        },
        f_reg: {
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        },
        ordenamiento: {
            type: DataTypes.INTEGER,
        },
    },
    {
        tableName: 'sub_modulo',
        createdAt: false,
        updatedAt: false
    }
);
// sub_moduloModel.sync()
// sub_moduloModel.sync({ force: true })
module.exports = sub_moduloModel;