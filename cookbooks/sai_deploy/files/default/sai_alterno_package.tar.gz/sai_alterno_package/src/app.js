const version = '20250213';

require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const routes = require('./routes/router');
const { QueryTypes } = require('sequelize');

const servicePort = process.env.APP_PORT || 30057; // Usa el puerto del .env o 30057 por defecto

const app = express();

// Configuración básica de Express
app.set('views', 'src/views');
app.set('view engine', 'ejs');

app.use(express.static('src/public'));
app.use(express.urlencoded({ extended: true, limit: '200kb' }));
app.use(express.json({ limit: '200kb' }));
app.use(cookieParser());

// Variables globales para las vistas
app.use(function(req, res, next) {
  res.set('SRC-' + 'C' + '_v', version);
  res.locals.version = version;
  res.locals.appName = process.env.APP_NAME;
  res.locals.produccion = process.env.PRODUCCION == 'true';
  res.locals.title = process.env.APP_TITLE;
  res.locals.captchaMostrar = process.env.CAPTCHA_MOSTRAR == 'true';
  res.locals.captchaSitekey = process.env.CAPTCHA_SITEKEY;
  next();
});

app.use('/', routes);

// Conexión a la base de datos y carga de catálogos
const dbConection = require('./config/postgressdb');
const cat_type_usersModel = require('../src/models/cat_type_users');

// Iniciar servidor HTTP (sin HTTPS)
app.listen(servicePort, async function() {
  console.log(`Servidor HTTP iniciado en puerto ${servicePort}`);
  
  try {
    global.catalogos = {};
    
    // Cargar catálogos
    const cat_type_users = await cat_type_usersModel.findAll({
      where: { vigente: true },
      order: [['id_cat_type_users', 'ASC']]
    });
    if (!cat_type_users) throw new Error('No existe el catálogo de tipos de usuarios');
    global.catalogos.cat_type_users = cat_type_users.map(e => e.dataValues);
    
    const sub_modulo = await dbConection.query(
      `SELECT * FROM sub_modulo WHERE visible=true ORDER BY ordenamiento ASC;`,
      { type: QueryTypes.SELECT }
    );
    if (!sub_modulo) throw new Error('No existe el catálogo de submódulos');
    global.catalogos.sub_modulo = sub_modulo;
    
    const cat_entidad_federativa = await dbConection.query(
      `SELECT * FROM cat_estados;`,
      { type: QueryTypes.SELECT }
    );
    if (!cat_entidad_federativa) throw new Error('No existe el catálogo de entidad federativa');
    global.catalogos.cat_entidad_federativa = cat_entidad_federativa;
    
    console.log('Catálogos cargados correctamente');
    console.log(new Date().toLocaleString('es-MX', { timeZone: 'UTC', dateStyle: 'short' }));
    
  } catch (error) {
    console.error('Error al cargar catálogos:', error);
    process.exit(1); // Termina la aplicación si hay error en los catálogos
  }
});
