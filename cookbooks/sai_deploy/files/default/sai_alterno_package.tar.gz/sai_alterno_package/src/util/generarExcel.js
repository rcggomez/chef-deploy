const fs = require('fs');
const ExcelJS = require('exceljs');
const getNombreEntidad = require('../util/diccionario');
const path = require("path");
const os = require("os");

async function generarXLSFormulario(data){
  //console.log(data);
  try {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'IMSS Bienestar'
    workbook.lastModifiedBy = 'Bot'
    workbook.created = new Date(Date.now())
    workbook.modified = new Date(Date.now())
    workbook.lastPrinted = new Date(Date.now())

    const worksheet = workbook.addWorksheet('Formulario', { pageSetup: { paperSize: 9, orientation: "landscape" } });

    worksheet.columns = [
      {header: 'ID', key: 'id_formulario'},
      {header: 'Fecha Registro', key: 'fecha_registro'},
      // {header: 'Hora Registro', key: 'hora_registro'},
      {header: 'Entidad Federativa', key: 'entidad_fed'},
      {header: 'CLUES', key: 'clues'},
      {header: 'Numero Recetas Expedidas', key: 'num_recetas_expedidas'},
      {header: 'Numero Recetas Negadas', key: 'num_recetas_negadas'},
      {header: 'Numero Recetas Atendidas Parcialmente', key: 'num_recetas_atendidas_parcialmente'},
      {header: 'Numero Recetas Atendidas Manera Completa', key: 'num_recetas_atendidas_manera_completa'},
      
    ]

    data.forEach((item) => {
      item.dataValues.entidad_fed = getNombreEntidad(item.dataValues.entidad_fed);
      worksheet.addRow(item.dataValues)
    })

    worksheet.eachRow((row) => {
      row.eachCell((cell, colNumber) => {
        // cell.width = 40
        
        cell.font = { color: { argb: '000000' }, size: 11 };
        cell.alignment = { wrapText: false, vertical: 'middle' };
      })
    })


    worksheet.columns.forEach((column) => {
      let maxLength = 0;
      column["eachCell"]({ includeEmpty: true }, (cell) => {
          const columnLength = cell.value ? cell.value.toString().length + 3 : 10;
          if (cell.type === ExcelJS.ValueType.Date) {
              maxLength = 20;
          }
          else if (columnLength > maxLength) {
              maxLength = columnLength + 3;
          }
      });
      column.width = maxLength < 10 ? 10 : maxLength;
  });

    worksheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, color: { argb: '000000' }, size: 11 };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '83cceb' }
      };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });

    return workbook.xlsx.writeBuffer();
  } catch (error) {
    console.log(error);
  }
}


async function generarXLSFormularioRecetas(data) {
  const filePath = path.join(os.tmpdir(), `formulario_recetas_${Date.now()}.xlsx`);

  return new Promise((resolve, reject) => {
    try {
      const workbook = new ExcelJS.stream.xlsx.WorkbookWriter({
        filename: filePath,
        useStyles: true,
        useSharedStrings: true
      });

      const worksheet = workbook.addWorksheet("Formulario");

      worksheet.columns = [
        { header: "ID", key: "id_receta", width: 10 },
        { header: "Entidad Federativa", key: "estado", width: 20 },
        { header: "CLUES", key: "clues", width: 15 },
        { header: "Folio", key: "folio", width: 15 },
        { header: "Receta Comunitaria", key: "receta_comunitaria", width: 20 },
        { header: "Fecha Preescripción", key: "fecha_preescripcion", width: 20 },
        { header: "Fecha Surtimiento", key: "fecha_surtimiento", width: 20 },
        { header: "Clave Sector Salud", key: "clave_sector_salud", width: 20 },
        { header: "Descripción", key: "descripcion", width: 30 },
        { header: "Presentación", key: "presentacion", width: 20 },
        { header: "Cantidad Recetada", key: "cantidad_receptida", width: 20 },
        { header: "Cantidad Expedida", key: "cantidad_expedida", width: 20 },
      ];

      for (const item of data) {
        worksheet.addRow(item).commit();
      }

      worksheet.commit();

      workbook.commit().then(() => {
        fs.readFile(filePath, (err, buffer) => {
          if (err) return reject(err);

          fs.unlink(filePath, () => {}); 
          resolve(buffer); 
        });
      });
    } catch (err) {
      reject(err);
    }
  });
}

async function generarXLSFormularioProduccion(data) {
  const filePath = path.join(os.tmpdir(), `formulario_produccion_${Date.now()}.xlsx`);

  return new Promise((resolve, reject) => {
    try {
      const workbook = new ExcelJS.stream.xlsx.WorkbookWriter({
        filename: filePath,
        useStyles: true,
        useSharedStrings: true
      });

      const worksheet = workbook.addWorksheet("Formulario");

      worksheet.columns = [
        { header: "ID", key: "id_produccion", width: 10 },
        { header: "Entidad Federativa", key: "estado", width: 20 },
        { header: "CLUES", key: "clues", width: 15 },
        { header: "Fecha Inicio de Reporte", key: "fecha_preescripcion", width: 20 },
        { header: "Fecha Fin de Reporte", key: "fecha_surtimiento", width: 20 },
        { header: "ID Servicio", key: "id", width: 20 },
        { header: "Descripción", key: "descripcion", width: 30 },
        { header: "Tipo", key: "tipo", width: 20 },
        { header: "Número de Servicios ", key: "cantidad_receptida", width: 20 },
        { header: "% de Sastifaccion", key: "cantidad_expedida", width: 20 },
      ];

      for (const item of data) {
        worksheet.addRow(item).commit();
      }

      worksheet.commit();

      workbook.commit().then(() => {
        fs.readFile(filePath, (err, buffer) => {
          if (err) return reject(err);

          fs.unlink(filePath, () => {}); 
          resolve(buffer); 
        });
      });
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = {
  generarXLSFormulario,
  generarXLSFormularioRecetas,
  generarXLSFormularioProduccion,
};
