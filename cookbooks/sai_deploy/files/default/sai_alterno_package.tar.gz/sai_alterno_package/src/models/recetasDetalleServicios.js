const dbConection = require('../config/postgressdb');
const { Sequelize, DataTypes } = require('sequelize');

const recetasDetalleServicios = dbConection.define('recetas_detalle_servicios',
    {
        id_detalle_servicio:{
            type:  DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        fk_id_produccion: {
            type: DataTypes.INTEGER,
            //allowNull: false,
            /* references: {
                model: 'recetas',
                key: 'id_receta',
            },
            onDelete: 'RESTRICT', */
        },
        fk_id_servicio: {
            type: DataTypes.INTEGER,
            //allowNull: false,
        },
        cantidad_receptida: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        cantidad_expedida: {
            type: DataTypes.STRING,
            //allowNull: false,
        },
        estatus: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        created_at:{
            type: 'TIMESTAMP WITHOUT TIME ZONE',
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        }
    },
    {
        createdAt: false,
        updatedAt: false,
        tableName: 'recetas_detalle_servicios'
    }
    
);
// FormularioUnidadHospitalariaModel.sync({force:true})
recetasDetalleServicios.removeAttribute('id');

module.exports = recetasDetalleServicios;
